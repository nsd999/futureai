import { relations } from "drizzle-orm";
import { users, profiles, simulationRuns, futures, analysisScores, chatMessages, generatedContent } from "./schema";

export const usersRelations = relations(users, ({ many }) => ({
  profiles: many(profiles),
  simulationRuns: many(simulationRuns),
  chatMessages: many(chatMessages),
}));

export const profilesRelations = relations(profiles, ({ one, many }) => ({
  user: one(users, { fields: [profiles.userId], references: [users.id] }),
  simulationRuns: many(simulationRuns),
}));

export const simulationRunsRelations = relations(simulationRuns, ({ one, many }) => ({
  user: one(users, { fields: [simulationRuns.userId], references: [users.id] }),
  profile: one(profiles, { fields: [simulationRuns.profileId], references: [profiles.id] }),
  futures: many(futures),
  analysisScores: many(analysisScores),
  chatMessages: many(chatMessages),
  generatedContent: many(generatedContent),
}));

export const futuresRelations = relations(futures, ({ one }) => ({
  simulationRun: one(simulationRuns, { fields: [futures.simulationRunId], references: [simulationRuns.id] }),
}));

export const analysisScoresRelations = relations(analysisScores, ({ one }) => ({
  simulationRun: one(simulationRuns, { fields: [analysisScores.simulationRunId], references: [simulationRuns.id] }),
}));

export const chatMessagesRelations = relations(chatMessages, ({ one }) => ({
  user: one(users, { fields: [chatMessages.userId], references: [users.id] }),
  simulationRun: one(simulationRuns, { fields: [chatMessages.simulationRunId], references: [simulationRuns.id] }),
}));

export const generatedContentRelations = relations(generatedContent, ({ one }) => ({
  simulationRun: one(simulationRuns, { fields: [generatedContent.simulationRunId], references: [simulationRuns.id] }),
}));
