import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  json,
  bigint,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  name: varchar("name", { length: 255 }),
  email: varchar("email", { length: 320 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const profiles = mysqlTable("profiles", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  rawText: text("rawText"),
  parsedData: json("parsedData").$type<Record<string, unknown>>(),
  personalDetails: json("personalDetails").$type<Record<string, unknown>>(),
  goals: json("goals").$type<string[]>(),
  habits: json("habits").$type<Record<string, string | number>>(),
  personality: json("personality").$type<Record<string, string>>(),
  preferences: json("preferences").$type<Record<string, unknown>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt")
    .defaultNow()
    .notNull()
    .$onUpdate(() => new Date()),
});

export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = typeof profiles.$inferInsert;

export const simulationRuns = mysqlTable("simulation_runs", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  profileId: bigint("profileId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => profiles.id),
  status: mysqlEnum("status", ["pending", "generating", "completed", "failed"])
    .default("pending")
    .notNull(),
  progressStep: int("progressStep").default(0),
  progressMessage: varchar("progressMessage", { length: 255 }),
  preferences: json("preferences").$type<Record<string, unknown>>(),
  generatedAt: timestamp("generatedAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SimulationRun = typeof simulationRuns.$inferSelect;

export const futures = mysqlTable("futures", {
  id: serial("id").primaryKey(),
  simulationRunId: bigint("simulationRunId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => simulationRuns.id),
  scenarioKey: varchar("scenarioKey", { length: 50 }).notNull(),
  scenarioLabel: varchar("scenarioLabel", { length: 255 }).notNull(),
  career: text("career"),
  income: text("income"),
  health: text("health"),
  relationships: text("relationships"),
  lifestyle: text("lifestyle"),
  dailyRoutine: text("dailyRoutine"),
  majorAchievements: json("majorAchievements").$type<string[]>(),
  majorMistakes: json("majorMistakes").$type<string[]>(),
  regrets: text("regrets"),
  lessonsLearned: text("lessonsLearned"),
  mentalHealth: text("mentalHealth"),
  socialLife: text("socialLife"),
  familySituation: text("familySituation"),
  skillsAcquired: json("skillsAcquired").$type<string[]>(),
  businessesCreated: json("businessesCreated").$type<string[]>(),
  projectsCompleted: json("projectsCompleted").$type<string[]>(),
  majorTurningPoints: json("majorTurningPoints").$type<string[]>(),
  unexpectedEvents: json("unexpectedEvents").$type<string[]>(),
  narrative: text("narrative"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Future = typeof futures.$inferSelect;

export const analysisScores = mysqlTable("analysis_scores", {
  id: serial("id").primaryKey(),
  simulationRunId: bigint("simulationRunId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => simulationRuns.id),
  growthPotential: int("growthPotential"),
  consistency: int("consistency"),
  risk: int("risk"),
  opportunity: int("opportunity"),
  discipline: int("discipline"),
  learning: int("learning"),
  relationshipStability: int("relationshipStability"),
  healthProjection: int("healthProjection"),
  careerProjection: int("careerProjection"),
  financialProjection: int("financialProjection"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnalysisScore = typeof analysisScores.$inferSelect;

export const chatMessages = mysqlTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => users.id),
  simulationRunId: bigint("simulationRunId", { mode: "number", unsigned: true }).references(
    () => simulationRuns.id
  ),
  role: mysqlEnum("role", ["user", "assistant", "system"]).notNull(),
  content: text("content").notNull(),
  context: json("context").$type<Record<string, unknown>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;

export const generatedContent = mysqlTable("generated_content", {
  id: serial("id").primaryKey(),
  simulationRunId: bigint("simulationRunId", { mode: "number", unsigned: true })
    .notNull()
    .references(() => simulationRuns.id),
  contentType: mysqlEnum("contentType", [
    "letter",
    "news_article",
    "linkedin_profile",
    "regret_analysis",
    "wake_up_call",
    "funeral_speech",
    "legacy_score",
  ]).notNull(),
  title: varchar("title", { length: 255 }),
  content: text("content").notNull(),
  metadata: json("metadata").$type<Record<string, unknown>>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type GeneratedContent = typeof generatedContent.$inferSelect;
