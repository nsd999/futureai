import { useRef, useMemo } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import * as THREE from "three";

const vertexShader = `
  uniform float uTime;
  uniform vec2 uMouse;
  uniform float uMouseInfluence;
  varying float vZ;

  vec3 mod289(vec3 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
  vec4 mod289(vec4 x) { return x - floor(x * (1.0 / 289.0)) * 289.0; }
  vec4 permute(vec4 x) { return mod289(((x*34.0)+1.0)*x); }
  vec4 taylorInvSqrt(vec4 r) { return 1.79284291400159 - 0.85373472095314 * r; }

  float snoise(vec3 v) {
    const vec2 C = vec2(1.0/6.0, 1.0/3.0);
    const vec4 D = vec4(0.0, 0.5, 1.0, 2.0);
    vec3 i = floor(v + dot(v, C.yyy));
    vec3 x0 = v - i + dot(i, C.xxx);
    vec3 g = step(x0.yzx, x0.xyz);
    vec3 l = 1.0 - g;
    vec3 i1 = min(g.xyz, l.zxy);
    vec3 i2 = max(g.xyz, l.zxy);
    vec3 x1 = x0 - i1 + C.xxx;
    vec3 x2 = x0 - i2 + C.yyy;
    vec3 x3 = x0 - D.yyy;
    i = mod289(i);
    vec4 p = permute(permute(permute(
      i.z + vec4(0.0, i1.z, i2.z, 1.0))
      + i.y + vec4(0.0, i1.y, i2.y, 1.0))
      + i.x + vec4(0.0, i1.x, i2.x, 1.0));
    float n_ = 0.142857142857;
    vec3 ns = n_ * D.wyz - D.xzx;
    vec4 j = p - 49.0 * floor(p * ns.z * ns.z);
    vec4 x_ = floor(j * ns.z);
    vec4 y_ = floor(j - 7.0 * x_);
    vec4 x = x_ *ns.x + ns.yyyy;
    vec4 y = y_ *ns.x + ns.yyyy;
    vec4 h = 1.0 - abs(x) - abs(y);
    vec4 b0 = vec4(x.xy, y.xy);
    vec4 b1 = vec4(x.zw, y.zw);
    vec4 s0 = floor(b0)*2.0 + 1.0;
    vec4 s1 = floor(b1)*2.0 + 1.0;
    vec4 sh = -step(h, vec4(0.0));
    vec4 a0 = b0.xzyw + s0.xzyw*sh.xxyy;
    vec4 a1 = b1.xzyw + s1.xzyw*sh.zzww;
    vec3 p0 = vec3(a0.xy, h.x);
    vec3 p1 = vec3(a0.zw, h.y);
    vec3 p2 = vec3(a1.xy, h.z);
    vec3 p3 = vec3(a1.zw, h.w);
    vec4 norm = taylorInvSqrt(vec4(dot(p0,p0), dot(p1,p1), dot(p2,p2), dot(p3,p3)));
    p0 *= norm.x; p1 *= norm.y; p2 *= norm.z; p3 *= norm.w;
    vec4 m = max(0.6 - vec4(dot(x0,x0), dot(x1,x1), dot(x2,x2), dot(x3,x3)), 0.0);
    m = m * m;
    return 42.0 * dot(m*m, vec4(dot(p0,x0), dot(p1,x1), dot(p2,x2), dot(p3,x3)));
  }

  void main() {
    vec3 pos = position;
    float t = uTime * 0.25;
    float n1 = snoise(vec3(pos.x * 0.08, pos.y * 0.08, t));
    float n2 = snoise(vec3(pos.x * 0.2, pos.y * 0.2, t * 1.5));
    float totalNoise = (n1 * 4.0) + (n2 * 1.0);

    if (uMouseInfluence > 0.0) {
      float dx = pos.x - uMouse.x;
      float dy = pos.y - uMouse.y;
      float dist = sqrt(dx*dx + dy*dy);
      float falloff = exp(-dist * dist * 0.015);
      float push = falloff * uMouseInfluence * 6.0;
      float angle = atan(dy, dx);
      totalNoise += cos(angle) * push;
      totalNoise += sin(angle) * push;
    }

    pos.z = totalNoise;
    vZ = totalNoise;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(pos, 1.0);
  }
`;

const fragmentShader = `
  uniform vec3 uBaseColor;
  uniform float uLineIntensity;
  uniform float uFadeOpacity;
  varying float vZ;

  void main() {
    vec3 color = uBaseColor + (vZ * 0.15);
    float alpha = 1.0 - uFadeOpacity;
    gl_FragColor = vec4(color * uLineIntensity, alpha);
  }
`;

function Grid() {
  const meshRef = useRef<THREE.Mesh>(null);
  const mouseRef = useRef({ x: 0, y: 0 });
  const mouseInfluenceRef = useRef(0);
  const lastMoveTimeRef = useRef(0);

  const { viewport } = useThree();

  const uniforms = useMemo(
    () => ({
      uTime: { value: 0 },
      uMouse: { value: new THREE.Vector2(0, 0) },
      uMouseInfluence: { value: 0 },
      uBaseColor: { value: new THREE.Vector3(0.15, 0.18, 0.22) },
      uLineIntensity: { value: 0.6 },
      uFadeOpacity: { value: 0.0 },
    }),
    []
  );

  useFrame((state) => {
    const time = state.clock.getElapsedTime();
    const mouse = state.mouse;

    const worldMouseX = mouse.x * viewport.width * 0.5;
    const worldMouseY = mouse.y * viewport.height * 0.5;

    if (
      Math.abs(mouse.x) > 0.001 ||
      Math.abs(mouse.y) > 0.001
    ) {
      mouseRef.current.x = worldMouseX;
      mouseRef.current.y = worldMouseY;
      lastMoveTimeRef.current = time;
      mouseInfluenceRef.current += (1 - mouseInfluenceRef.current) * 0.05;
    } else if (time - lastMoveTimeRef.current > 2) {
      mouseInfluenceRef.current += (0 - mouseInfluenceRef.current) * 0.02;
    }

    const mat = meshRef.current?.material as THREE.ShaderMaterial;
    if (mat) {
      mat.uniforms.uTime.value = time;
      mat.uniforms.uMouse.value.set(mouseRef.current.x, mouseRef.current.y);
      mat.uniforms.uMouseInfluence.value = mouseInfluenceRef.current;
    }

    if (meshRef.current) {
      meshRef.current.rotation.y += 0.0005;
    }
  });

  return (
    <mesh ref={meshRef} position={[0, 0, -12]} rotation={[-0.3, 0, 0]}>
      <planeGeometry args={[70, 70, 80, 80]} />
      <shaderMaterial
        vertexShader={vertexShader}
        fragmentShader={fragmentShader}
        uniforms={uniforms}
        transparent
        wireframe
      />
    </mesh>
  );
}

export default function NoiseGridBackground() {
  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        width: "100%",
        height: "100%",
        zIndex: 0,
        pointerEvents: "none",
      }}
    >
      <Canvas
        camera={{ position: [0, 0, 5], fov: 75 }}
        style={{ width: "100%", height: "100%" }}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={0.3} />
        <pointLight color="#C17F59" intensity={0.4} position={[0, 0, 5]} />
        <Grid />
      </Canvas>
    </div>
  );
}
