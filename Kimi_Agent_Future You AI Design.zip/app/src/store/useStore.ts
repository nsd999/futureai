import { create } from "zustand";
import { persist } from "zustand/middleware";

interface PersonalDetails {
  currentAge: number;
  gender: string;
  country: string;
  city: string;
  educationLevel: string;
  currentOccupation: string;
  relationshipStatus: string;
  livingSituation: string;
  annualIncome: string;
  happinessLevel: number;
  stressLevel: number;
  confidenceLevel: number;
  healthLevel: number;
  productivityLevel: number;
}

interface Personality {
  biggestStrength: string;
  biggestWeakness: string;
  greatestFear: string;
  mostImportantValue: string;
  mostAdmiredPerson: string;
  procrastinationCause: string;
  motivationCause: string;
  decisionStyle: string;
  riskTolerance: string;
  introvertExtrovert: string;
  thinkingStyle: string;
}

interface FutureScenario {
  id?: number;
  scenarioKey: string;
  scenarioLabel: string;
  career: string;
  income: string;
  health: string;
  relationships: string;
  lifestyle: string;
  dailyRoutine: string;
  majorAchievements: string[];
  majorMistakes: string[];
  regrets: string;
  lessonsLearned: string;
  mentalHealth: string;
  socialLife: string;
  familySituation: string;
  skillsAcquired: string[];
  businessesCreated: string[];
  projectsCompleted: string[];
  majorTurningPoints: string[];
  unexpectedEvents: string[];
  narrative: string;
}

interface AnalysisScores {
  growthPotential: number;
  consistency: number;
  risk: number;
  opportunity: number;
  discipline: number;
  learning: number;
  relationshipStability: number;
  healthProjection: number;
  careerProjection: number;
  financialProjection: number;
}

interface ChatMessage {
  id?: number;
  role: "user" | "assistant";
  content: string;
  createdAt?: Date;
}

interface GeneratedContent {
  id?: number;
  contentType: string;
  title: string | null;
  content: string;
  metadata: Record<string, unknown> | null;
}

interface AppState {
  // Onboarding data
  importPrompt: string;
  importedProfile: string;
  personalDetails: PersonalDetails;
  goals: string[];
  habits: Record<string, string>;
  personality: Personality;
  currentStep: number;

  // Analysis
  scores: AnalysisScores | null;
  futures: FutureScenario[];
  isAnalyzing: boolean;
  analysisComplete: boolean;
  currentRunId: number | null;

  // Chat
  chatMessages: ChatMessage[];
  isTyping: boolean;

  // Generated content
  letter: GeneratedContent | null;
  newsArticle: GeneratedContent | null;
  linkedInProfile: GeneratedContent | null;
  regretAnalysis: GeneratedContent | null;

  // Actions
  setImportPrompt: (prompt: string) => void;
  setImportedProfile: (profile: string) => void;
  setPersonalDetails: (details: Partial<PersonalDetails>) => void;
  setGoals: (goals: string[]) => void;
  setHabits: (habits: Record<string, string>) => void;
  setPersonality: (personality: Partial<Personality>) => void;
  setCurrentStep: (step: number) => void;
  setScores: (scores: AnalysisScores) => void;
  setFutures: (futures: FutureScenario[]) => void;
  setIsAnalyzing: (v: boolean) => void;
  setAnalysisComplete: (v: boolean) => void;
  setCurrentRunId: (id: number | null) => void;
  addChatMessage: (msg: ChatMessage) => void;
  setChatMessages: (msgs: ChatMessage[]) => void;
  setIsTyping: (v: boolean) => void;
  setLetter: (letter: GeneratedContent | null) => void;
  setNewsArticle: (article: GeneratedContent | null) => void;
  setLinkedInProfile: (profile: GeneratedContent | null) => void;
  setRegretAnalysis: (analysis: GeneratedContent | null) => void;
  resetOnboarding: () => void;
  hasCompletedOnboarding: () => boolean;
}

const defaultPersonalDetails: PersonalDetails = {
  currentAge: 25,
  gender: "",
  country: "",
  city: "",
  educationLevel: "",
  currentOccupation: "",
  relationshipStatus: "",
  livingSituation: "",
  annualIncome: "",
  happinessLevel: 5,
  stressLevel: 5,
  confidenceLevel: 5,
  healthLevel: 5,
  productivityLevel: 5,
};

const defaultPersonality: Personality = {
  biggestStrength: "",
  biggestWeakness: "",
  greatestFear: "",
  mostImportantValue: "",
  mostAdmiredPerson: "",
  procrastinationCause: "",
  motivationCause: "",
  decisionStyle: "",
  riskTolerance: "medium",
  introvertExtrovert: "",
  thinkingStyle: "",
};

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      importPrompt: "",
      importedProfile: "",
      personalDetails: { ...defaultPersonalDetails },
      goals: [],
      habits: {},
      personality: { ...defaultPersonality },
      currentStep: 0,
      scores: null,
      futures: [],
      isAnalyzing: false,
      analysisComplete: false,
      currentRunId: null,
      chatMessages: [],
      isTyping: false,
      letter: null,
      newsArticle: null,
      linkedInProfile: null,
      regretAnalysis: null,

      setImportPrompt: (prompt) => set({ importPrompt: prompt }),
      setImportedProfile: (profile) => set({ importedProfile: profile }),
      setPersonalDetails: (details) =>
        set((state) => ({
          personalDetails: { ...state.personalDetails, ...details },
        })),
      setGoals: (goals) => set({ goals }),
      setHabits: (habits) => set({ habits }),
      setPersonality: (personality) =>
        set((state) => ({
          personality: { ...state.personality, ...personality },
        })),
      setCurrentStep: (step) => set({ currentStep: step }),
      setScores: (scores) => set({ scores }),
      setFutures: (futures) => set({ futures }),
      setIsAnalyzing: (v) => set({ isAnalyzing: v }),
      setAnalysisComplete: (v) => set({ analysisComplete: v }),
      setCurrentRunId: (id) => set({ currentRunId: id }),
      addChatMessage: (msg) =>
        set((state) => ({ chatMessages: [...state.chatMessages, msg] })),
      setChatMessages: (msgs) => set({ chatMessages: msgs }),
      setIsTyping: (v) => set({ isTyping: v }),
      setLetter: (letter) => set({ letter }),
      setNewsArticle: (article) => set({ newsArticle: article }),
      setLinkedInProfile: (profile) => set({ linkedInProfile: profile }),
      setRegretAnalysis: (analysis) => set({ regretAnalysis: analysis }),

      resetOnboarding: () =>
        set({
          importPrompt: "",
          importedProfile: "",
          personalDetails: { ...defaultPersonalDetails },
          goals: [],
          habits: {},
          personality: { ...defaultPersonality },
          currentStep: 0,
          scores: null,
          futures: [],
          isAnalyzing: false,
          analysisComplete: false,
          currentRunId: null,
          chatMessages: [],
          letter: null,
          newsArticle: null,
          linkedInProfile: null,
          regretAnalysis: null,
        }),

      hasCompletedOnboarding: () => {
        const state = get();
        return (
          state.personalDetails.currentAge > 0 &&
          state.personalDetails.country.length > 0 &&
          state.goals.length > 0 &&
          state.personality.biggestStrength.length > 0
        );
      },
    }),
    {
      name: "future-you-ai",
      partialize: (state) => ({
        importedProfile: state.importedProfile,
        personalDetails: state.personalDetails,
        goals: state.goals,
        habits: state.habits,
        personality: state.personality,
        currentStep: state.currentStep,
        scores: state.scores,
        futures: state.futures,
        analysisComplete: state.analysisComplete,
        currentRunId: state.currentRunId,
        chatMessages: state.chatMessages,
        letter: state.letter,
        newsArticle: state.newsArticle,
        linkedInProfile: state.linkedInProfile,
        regretAnalysis: state.regretAnalysis,
      }),
    }
  )
);
