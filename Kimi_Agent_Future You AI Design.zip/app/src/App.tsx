import { Routes, Route } from "react-router";
import { lazy, Suspense } from "react";
import NoiseGridBackground from "@/effects/NoiseGrid";

const WelcomePage = lazy(() => import("@/pages/WelcomePage"));
const ImportContextPage = lazy(() => import("@/pages/ImportContextPage"));
const PasteProfilePage = lazy(() => import("@/pages/PasteProfilePage"));
const PersonalDetailsPage = lazy(() => import("@/pages/PersonalDetailsPage"));
const GoalsPage = lazy(() => import("@/pages/GoalsPage"));
const HabitsPage = lazy(() => import("@/pages/HabitsPage"));
const PersonalityPage = lazy(() => import("@/pages/PersonalityPage"));
const AnalyzingPage = lazy(() => import("@/pages/AnalyzingPage"));
const FuturesPage = lazy(() => import("@/pages/FuturesPage"));
const ChatPage = lazy(() => import("@/pages/ChatPage"));
const LetterPage = lazy(() => import("@/pages/LetterPage"));
const NewsPage = lazy(() => import("@/pages/NewsPage"));
const LinkedInPage = lazy(() => import("@/pages/LinkedInPage"));
const RegretsPage = lazy(() => import("@/pages/RegretsPage"));
const Login = lazy(() => import("@/pages/Login"));
const NotFound = lazy(() => import("@/pages/NotFound"));

function LoadingFallback() {
  return (
    <div className="min-h-screen flex items-center justify-center relative z-10">
      <div className="flex flex-col items-center gap-4">
        <div
          className="w-12 h-12 rounded-full border-2 border-t-transparent animate-spin"
          style={{ borderColor: "var(--accent)", borderTopColor: "transparent" }}
        />
        <span className="text-sm" style={{ color: "var(--text-secondary)" }}>
          Loading...
        </span>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <>
      <NoiseGridBackground />
      <Suspense fallback={<LoadingFallback />}>
        <Routes>
          <Route path="/" element={<WelcomePage />} />
          <Route path="/import" element={<ImportContextPage />} />
          <Route path="/profile" element={<PasteProfilePage />} />
          <Route path="/details" element={<PersonalDetailsPage />} />
          <Route path="/goals" element={<GoalsPage />} />
          <Route path="/habits" element={<HabitsPage />} />
          <Route path="/personality" element={<PersonalityPage />} />
          <Route path="/analyzing" element={<AnalyzingPage />} />
          <Route path="/futures" element={<FuturesPage />} />
          <Route path="/chat" element={<ChatPage />} />
          <Route path="/letter" element={<LetterPage />} />
          <Route path="/news" element={<NewsPage />} />
          <Route path="/linkedin" element={<LinkedInPage />} />
          <Route path="/regrets" element={<RegretsPage />} />
          <Route path="/login" element={<Login />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
    </>
  );
}
