import { motion } from "framer-motion";
import { ArrowRight, ArrowLeft, User, Heart, Brain, Zap, Shield } from "lucide-react";
import { useNavigate } from "react-router";
import { useStore } from "@/store/useStore";

const educationLevels = [
  "High School",
  "Some College",
  "Associate Degree",
  "Bachelor's Degree",
  "Master's Degree",
  "Doctorate",
  "Professional Degree",
  "Other",
];

const relationshipStatuses = [
  "Single",
  "In a Relationship",
  "Engaged",
  "Married",
  "Divorced",
  "Widowed",
  "It's Complicated",
];

const livingSituations = [
  "Living Alone",
  "With Partner/Spouse",
  "With Family",
  "With Roommates",
  "Other",
];

function SliderField({
  label,
  value,
  onChange,
  icon: Icon,
  min = 1,
  max = 10,
}: {
  label: string;
  value: number;
  onChange: (v: number) => void;
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  min?: number;
  max?: number;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4" style={{ color: "var(--accent)" }} />
          <span className="text-sm font-medium" style={{ color: "var(--text)" }}>
            {label}
          </span>
        </div>
        <span
          className="font-mono-data text-lg font-medium"
          style={{ color: "var(--accent)" }}
        >
          {value}
        </span>
      </div>
      <input
        type="range"
        min={min}
        max={max}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full h-2 rounded-lg appearance-none cursor-pointer"
        style={{
          background: `linear-gradient(to right, var(--accent) 0%, var(--accent) ${((value - min) / (max - min)) * 100}%, var(--slate-lighter) ${((value - min) / (max - min)) * 100}%, var(--slate-lighter) 100%)`,
          accentColor: "var(--accent)",
        }}
      />
      <div className="flex justify-between text-xs" style={{ color: "var(--text-secondary)" }}>
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );
}

export default function PersonalDetailsPage() {
  const navigate = useNavigate();
  const { personalDetails, setPersonalDetails } = useStore();

  const isValid =
    personalDetails.currentAge > 0 &&
    personalDetails.country.length > 0 &&
    personalDetails.city.length > 0 &&
    personalDetails.currentOccupation.length > 0;

  return (
    <div className="min-h-screen flex items-start justify-center relative z-10 px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.175, 0.885, 0.32, 1.275] }}
        className="w-full max-w-3xl"
      >
        <div className="card-surface p-8 md:p-10">
          <div className="flex items-center gap-3 mb-2">
            <User className="w-6 h-6" style={{ color: "var(--accent)" }} />
            <span className="font-label">Step 4 of 7</span>
          </div>
          <h1
            className="text-3xl md:text-4xl font-display mb-6"
            style={{ color: "var(--text)" }}
          >
            Personal Details
          </h1>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-label block mb-2">Current Age *</label>
                <input
                  type="number"
                  value={personalDetails.currentAge || ""}
                  onChange={(e) =>
                    setPersonalDetails({ currentAge: Number(e.target.value) })
                  }
                  placeholder="25"
                  min={13}
                  max={100}
                  className="input-dark h-12"
                />
              </div>
              <div>
                <label className="font-label block mb-2">Gender</label>
                <select
                  value={personalDetails.gender}
                  onChange={(e) => setPersonalDetails({ gender: e.target.value })}
                  className="input-dark h-12"
                  style={{ appearance: "auto" }}
                >
                  <option value="">Select</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Non-binary">Non-binary</option>
                  <option value="Prefer not to say">Prefer not to say</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-label block mb-2">Country *</label>
                <input
                  type="text"
                  value={personalDetails.country}
                  onChange={(e) => setPersonalDetails({ country: e.target.value })}
                  placeholder="United States"
                  className="input-dark h-12"
                />
              </div>
              <div>
                <label className="font-label block mb-2">City *</label>
                <input
                  type="text"
                  value={personalDetails.city}
                  onChange={(e) => setPersonalDetails({ city: e.target.value })}
                  placeholder="New York"
                  className="input-dark h-12"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-label block mb-2">Education Level</label>
                <select
                  value={personalDetails.educationLevel}
                  onChange={(e) =>
                    setPersonalDetails({ educationLevel: e.target.value })
                  }
                  className="input-dark h-12"
                  style={{ appearance: "auto" }}
                >
                  <option value="">Select</option>
                  {educationLevels.map((level) => (
                    <option key={level} value={level}>
                      {level}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-label block mb-2">Current Occupation *</label>
                <input
                  type="text"
                  value={personalDetails.currentOccupation}
                  onChange={(e) =>
                    setPersonalDetails({ currentOccupation: e.target.value })
                  }
                  placeholder="Software Engineer"
                  className="input-dark h-12"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-label block mb-2">Relationship Status</label>
                <select
                  value={personalDetails.relationshipStatus}
                  onChange={(e) =>
                    setPersonalDetails({ relationshipStatus: e.target.value })
                  }
                  className="input-dark h-12"
                  style={{ appearance: "auto" }}
                >
                  <option value="">Select</option>
                  {relationshipStatuses.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="font-label block mb-2">Living Situation</label>
                <select
                  value={personalDetails.livingSituation}
                  onChange={(e) =>
                    setPersonalDetails({ livingSituation: e.target.value })
                  }
                  className="input-dark h-12"
                  style={{ appearance: "auto" }}
                >
                  <option value="">Select</option>
                  {livingSituations.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="font-label block mb-2">Annual Income (Optional)</label>
              <input
                type="text"
                value={personalDetails.annualIncome}
                onChange={(e) => setPersonalDetails({ annualIncome: e.target.value })}
                placeholder="e.g., $50,000 - $75,000"
                className="input-dark h-12"
              />
            </div>

            <div className="pt-4 border-t" style={{ borderColor: "var(--border)" }}>
              <h3
                className="text-lg font-medium mb-4"
                style={{ color: "var(--text)" }}
              >
                Current Self-Assessment
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <SliderField
                  label="Happiness Level"
                  value={personalDetails.happinessLevel}
                  onChange={(v) => setPersonalDetails({ happinessLevel: v })}
                  icon={Heart}
                />
                <SliderField
                  label="Stress Level"
                  value={personalDetails.stressLevel}
                  onChange={(v) => setPersonalDetails({ stressLevel: v })}
                  icon={Zap}
                />
                <SliderField
                  label="Confidence Level"
                  value={personalDetails.confidenceLevel}
                  onChange={(v) => setPersonalDetails({ confidenceLevel: v })}
                  icon={Shield}
                />
                <SliderField
                  label="Health Level"
                  value={personalDetails.healthLevel}
                  onChange={(v) => setPersonalDetails({ healthLevel: v })}
                  icon={Heart}
                />
                <SliderField
                  label="Productivity Level"
                  value={personalDetails.productivityLevel}
                  onChange={(v) => setPersonalDetails({ productivityLevel: v })}
                  icon={Brain}
                />
              </div>
            </div>
          </div>

          <div className="flex justify-between mt-10">
            <button
              onClick={() => navigate("/profile")}
              className="btn-secondary flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
            <button
              onClick={() => navigate("/goals")}
              disabled={!isValid}
              className="btn-accent flex items-center gap-2 py-4 px-8 text-base disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
