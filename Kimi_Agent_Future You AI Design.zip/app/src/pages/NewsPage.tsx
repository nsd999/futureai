import { motion } from "framer-motion";
import { ArrowLeft, Newspaper, Calendar, Tag } from "lucide-react";
import { useNavigate } from "react-router";
import { useStore } from "@/store/useStore";

export default function NewsPage() {
  const navigate = useNavigate();
  const { newsArticle } = useStore();

  if (!newsArticle) {
    return (
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <div className="text-center">
          <Newspaper className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--accent)" }} />
          <p style={{ color: "var(--text-secondary)" }}>No news article generated yet.</p>
          <button onClick={() => navigate("/futures")} className="btn-accent mt-4">
            Back to Futures
          </button>
        </div>
      </div>
    );
  }

  const meta = (newsArticle.metadata as Record<string, string>) ?? {};
  const lines = newsArticle.content.split("\n").filter((l) => l.trim());
  const headline = lines[0]?.replace("HEADLINE: ", "") ?? newsArticle.title;
  const bodyLines = lines.slice(1);

  return (
    <div className="min-h-screen relative z-10 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <button
            onClick={() => navigate("/futures")}
            className="flex items-center gap-2 text-sm mb-6 hover:underline"
            style={{ color: "var(--text-secondary)" }}
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Futures
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="card-surface p-8 md:p-10"
        >
          <div className="flex items-center gap-4 mb-6 pb-4 border-b" style={{ borderColor: "var(--border)" }}>
            <div
              className="w-12 h-12 rounded-xl flex items-center justify-center"
              style={{ background: "var(--accent-glow)" }}
            >
              <Newspaper className="w-6 h-6" style={{ color: "var(--accent)" }} />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-1">
                <span
                  className="text-sm font-medium"
                  style={{ color: "var(--accent)" }}
                >
                  {meta.publication ?? "Future Times"}
                </span>
                <span style={{ color: "var(--text-secondary)" }}>|</span>
                <span
                  className="flex items-center gap-1 text-sm"
                  style={{ color: "var(--text-secondary)" }}
                >
                  <Calendar className="w-3 h-3" />
                  {meta.date ?? "June 15, 2035"}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Tag className="w-3 h-3" style={{ color: "var(--text-secondary)" }} />
                <span
                  className="text-xs px-2 py-0.5 rounded-full"
                  style={{
                    background: "var(--accent-glow)",
                    color: "var(--accent-light)",
                  }}
                >
                  {meta.category ?? "Profile"}
                </span>
              </div>
            </div>
          </div>

          <h1
            className="text-2xl md:text-3xl font-display mb-6 leading-tight"
            style={{ color: "var(--text)" }}
          >
            {headline}
          </h1>

          <div className="space-y-4">
            {bodyLines.map((line, index) => {
              if (line.startsWith("• ")) {
                return (
                  <li
                    key={index}
                    className="ml-4 text-sm leading-relaxed"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {line.slice(2)}
                  </li>
                );
              }
              if (line === line.toUpperCase() && line.length < 50) {
                return (
                  <h3
                    key={index}
                    className="text-sm font-medium mt-6"
                    style={{ color: "var(--accent-light)" }}
                  >
                    {line}
                  </h3>
                );
              }
              return (
                <p
                  key={index}
                  className="text-sm leading-relaxed"
                  style={{ color: "var(--text-secondary)" }}
                >
                  {line}
                </p>
              );
            })}
          </div>

          <div
            className="mt-8 pt-6 border-t text-center"
            style={{ borderColor: "var(--border)" }}
          >
            <p className="text-xs" style={{ color: "var(--text-secondary)" }}>
              This article is a simulated projection based on your profile and goals.
            </p>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
