import { motion } from "framer-motion";
import { Sparkles, Brain, TrendingUp, FileText, MessageSquare, CheckCircle } from "lucide-react";
import { useNavigate } from "react-router";
import { useEffect, useState, useCallback } from "react";
import { useStore } from "@/store/useStore";
import { trpc } from "@/providers/trpc";

const STEPS = [
  { icon: Brain, label: "Analyzing your profile...", time: 800 },
  { icon: TrendingUp, label: "Projecting life trajectory...", time: 1200 },
  { icon: FileText, label: "Identifying turning points...", time: 1000 },
  { icon: MessageSquare, label: "Composing future letters...", time: 900 },
  { icon: Sparkles, label: "Your future self is ready", time: 600 },
];

export default function AnalyzingPage() {
  const navigate = useNavigate();
  const store = useStore();
  const [currentStep, setCurrentStep] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [error, setError] = useState("");

  const profileMutation = trpc.profile.create.useMutation();
  const simulationStart = trpc.simulation.start.useMutation();
  const futuresCreate = trpc.futures.create.useMutation();
  const scoresSave = trpc.futures.saveScores.useMutation();
  const contentCreate = trpc.content.create.useMutation();
  const simulationComplete = trpc.simulation.complete.useMutation();

  const runAnalysis = useCallback(async () => {
    try {
      setCurrentStep(0);
      await new Promise((r) => setTimeout(r, STEPS[0].time));

      setCurrentStep(1);
      const profileResult = await profileMutation.mutateAsync({
        rawText: store.importedProfile,
        personalDetails: store.personalDetails as unknown as Record<string, unknown>,
        goals: store.goals,
        habits: store.habits as Record<string, string | number>,
        personality: store.personality as unknown as Record<string, string>,
      });

      await new Promise((r) => setTimeout(r, STEPS[1].time));
      setCurrentStep(2);

      const { runId } = await simulationStart.mutateAsync({
        profileId: profileResult.id,
      });
      store.setCurrentRunId(runId);

      await new Promise((r) => setTimeout(r, STEPS[2].time));
      setCurrentStep(3);

      const { generateFuturesFromProfile, generateAnalysisScores, generateContent } =
        await import("../../api/lib/ai");

      const futures = await generateFuturesFromProfile({
        importedProfile: store.importedProfile,
        personalDetails: store.personalDetails as unknown as Record<string, unknown>,
        goals: store.goals,
        habits: store.habits as unknown as Record<string, unknown>,
        personality: store.personality as unknown as Record<string, unknown>,
      });

      for (const future of futures) {
        await futuresCreate.mutateAsync({
          simulationRunId: runId,
          scenarioKey: String(future.scenarioKey),
          scenarioLabel: String(future.scenarioLabel),
          career: String(future.career ?? ""),
          income: String(future.income ?? ""),
          health: String(future.health ?? ""),
          relationships: String(future.relationships ?? ""),
          lifestyle: String(future.lifestyle ?? ""),
          dailyRoutine: String(future.dailyRoutine ?? ""),
          majorAchievements: (future.majorAchievements as string[]) ?? [],
          majorMistakes: (future.majorMistakes as string[]) ?? [],
          regrets: String(future.regrets ?? ""),
          lessonsLearned: String(future.lessonsLearned ?? ""),
          mentalHealth: String(future.mentalHealth ?? ""),
          socialLife: String(future.socialLife ?? ""),
          familySituation: String(future.familySituation ?? ""),
          skillsAcquired: (future.skillsAcquired as string[]) ?? [],
          businessesCreated: (future.businessesCreated as string[]) ?? [],
          projectsCompleted: (future.projectsCompleted as string[]) ?? [],
          majorTurningPoints: (future.majorTurningPoints as string[]) ?? [],
          unexpectedEvents: (future.unexpectedEvents as string[]) ?? [],
          narrative: String(future.narrative ?? ""),
        });
      }

      const scores = await generateAnalysisScores({
        personalDetails: store.personalDetails as unknown as Record<string, unknown>,
        goals: store.goals,
        habits: store.habits as unknown as Record<string, unknown>,
        personality: store.personality as unknown as Record<string, unknown>,
      });

      const scoresTyped = scores as unknown as { growthPotential: number; consistency: number; risk: number; opportunity: number; discipline: number; learning: number; relationshipStability: number; healthProjection: number; careerProjection: number; financialProjection: number };
      await scoresSave.mutateAsync({
        simulationRunId: runId,
        ...scoresTyped,
      });
      store.setScores(scoresTyped);
      store.setFutures(futures as Array<{
        scenarioKey: string;
        scenarioLabel: string;
        career: string;
        income: string;
        health: string;
        relationships: string;
        lifestyle: string;
        dailyRoutine: string;
        majorAchievements: string[];
        majorMistakes: string[];
        regrets: string;
        lessonsLearned: string;
        mentalHealth: string;
        socialLife: string;
        familySituation: string;
        skillsAcquired: string[];
        businessesCreated: string[];
        projectsCompleted: string[];
        majorTurningPoints: string[];
        unexpectedEvents: string[];
        narrative: string;
      }>);

      await new Promise((r) => setTimeout(r, STEPS[3].time));
      setCurrentStep(4);

      const profileData = {
        importedProfile: store.importedProfile,
        personalDetails: store.personalDetails as unknown as Record<string, unknown>,
        goals: store.goals,
        habits: store.habits as unknown as Record<string, unknown>,
        personality: store.personality as unknown as Record<string, unknown>,
      };

      const letter = await generateContent("letter", profileData, futures);
      await contentCreate.mutateAsync({
        simulationRunId: runId,
        contentType: "letter",
        title: letter.title,
        content: letter.content,
        metadata: letter.metadata ?? {},
      });
      store.setLetter(letter as { contentType: string; title: string | null; content: string; metadata: Record<string, unknown> | null });

      const newsArticle = await generateContent("news_article", profileData, futures);
      await contentCreate.mutateAsync({
        simulationRunId: runId,
        contentType: "news_article",
        title: newsArticle.title,
        content: newsArticle.content,
        metadata: newsArticle.metadata ?? {},
      });
      store.setNewsArticle(newsArticle as { contentType: string; title: string | null; content: string; metadata: Record<string, unknown> | null });

      const linkedIn = await generateContent("linkedin_profile", profileData, futures);
      await contentCreate.mutateAsync({
        simulationRunId: runId,
        contentType: "linkedin_profile",
        title: linkedIn.title,
        content: linkedIn.content,
        metadata: linkedIn.metadata ?? {},
      });
      store.setLinkedInProfile(linkedIn as { contentType: string; title: string | null; content: string; metadata: Record<string, unknown> | null });

      const regrets = await generateContent("regret_analysis", profileData, futures);
      await contentCreate.mutateAsync({
        simulationRunId: runId,
        contentType: "regret_analysis",
        title: regrets.title,
        content: regrets.content,
        metadata: regrets.metadata ?? {},
      });
      store.setRegretAnalysis(regrets as { contentType: string; title: string | null; content: string; metadata: Record<string, unknown> | null });

      await simulationComplete.mutateAsync({ runId });
      store.setAnalysisComplete(true);

      await new Promise((r) => setTimeout(r, STEPS[4].time));
      setCompleted(true);

      setTimeout(() => {
        navigate("/futures");
      }, 1200);
    } catch (err) {
      console.error("Analysis error:", err);
      setError("Something went wrong. Please try again.");
    }
  }, [navigate, store]);

  useEffect(() => {
    runAnalysis();
  }, [runAnalysis]);

  return (
    <div className="min-h-screen flex items-center justify-center relative z-10 px-4">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="w-full max-w-xl"
      >
        <div className="card-surface p-10 md:p-12">
          <div className="flex justify-center mb-10">
            <motion.div
              animate={
                completed
                  ? { scale: [1, 1.2, 1], rotate: [0, 10, -10, 0] }
                  : { scale: [1, 1.05, 1] }
              }
              transition={
                completed
                  ? { duration: 0.6 }
                  : { repeat: Infinity, duration: 2 }
              }
              className="w-24 h-24 rounded-full flex items-center justify-center"
              style={{
                background:
                  "linear-gradient(135deg, var(--accent), var(--teal))",
                boxShadow: "0 0 40px var(--accent-glow)",
              }}
            >
              {completed ? (
                <CheckCircle className="w-10 h-10 text-white" />
              ) : (
                <Sparkles className="w-10 h-10 text-white" />
              )}
            </motion.div>
          </div>

          <h2
            className="text-2xl font-display text-center mb-2"
            style={{ color: "var(--text)" }}
          >
            {completed
              ? "Analysis Complete"
              : "Simulating Your Future Timeline..."}
          </h2>
          <p className="text-center mb-10" style={{ color: "var(--text-secondary)" }}>
            {completed
              ? "Redirecting you to your futures..."
              : "This may take a moment. We're analyzing every detail."}
          </p>

          {error && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="mb-6 p-4 rounded-xl text-center"
              style={{ background: "var(--rose-glow)", color: "var(--rose)" }}
            >
              {error}
            </motion.div>
          )}

          <div className="space-y-4">
            {STEPS.map((step, index) => {
              const Icon = step.icon;
              const isActive = index === currentStep;
              const isDone = index < currentStep || completed;

              return (
                <motion.div
                  key={step.label}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                  className="flex items-center gap-4 p-4 rounded-xl transition-all"
                  style={{
                    background: isActive
                      ? "var(--accent-glow)"
                      : isDone
                        ? "rgba(74, 155, 142, 0.08)"
                        : "transparent",
                    border: `1px solid ${
                      isActive
                        ? "var(--border-active)"
                        : isDone
                          ? "rgba(74, 155, 142, 0.2)"
                          : "var(--border)"
                    }`,
                  }}
                >
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{
                      background: isDone
                        ? "var(--teal)"
                        : isActive
                          ? "var(--accent)"
                          : "var(--slate-lighter)",
                    }}
                  >
                    {isDone ? (
                      <CheckCircle className="w-5 h-5 text-white" />
                    ) : (
                      <Icon className="w-5 h-5 text-white" />
                    )}
                  </div>
                  <span
                    className="text-sm font-medium"
                    style={{
                      color: isDone || isActive ? "var(--text)" : "var(--text-secondary)",
                    }}
                  >
                    {step.label}
                  </span>
                  {isActive && !completed && (
                    <motion.div
                      className="ml-auto w-5 h-5 border-2 border-t-transparent rounded-full"
                      style={{ borderColor: "var(--accent)", borderTopColor: "transparent" }}
                      animate={{ rotate: 360 }}
                      transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                    />
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
