import { motion, AnimatePresence } from "framer-motion";
import { ArrowRight, ArrowLeft, Target, X, Plus, Lightbulb } from "lucide-react";
import { useNavigate } from "react-router";
import { useState, useRef } from "react";
import { useStore } from "@/store/useStore";

const GOAL_EXAMPLES = [
  "Become financially independent",
  "Start a business",
  "Build a large audience",
  "Become a software engineer",
  "Become physically fit",
  "Buy a home",
  "Travel internationally",
  "Support family",
  "Master a skill",
  "Generate passive income",
];

export default function GoalsPage() {
  const navigate = useNavigate();
  const { goals, setGoals } = useStore();
  const [inputValue, setInputValue] = useState("");
  const [showExamples, setShowExamples] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const addGoal = (goal: string) => {
    const trimmed = goal.trim();
    if (trimmed && !goals.includes(trimmed)) {
      setGoals([...goals, trimmed]);
    }
    setInputValue("");
    inputRef.current?.focus();
  };

  const removeGoal = (index: number) => {
    setGoals(goals.filter((_, i) => i !== index));
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      e.preventDefault();
      addGoal(inputValue);
    }
  };

  return (
    <div className="min-h-screen flex items-start justify-center relative z-10 px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.175, 0.885, 0.32, 1.275] }}
        className="w-full max-w-3xl"
      >
        <div className="card-surface p-8 md:p-10">
          <div className="flex items-center gap-3 mb-2">
            <Target className="w-6 h-6" style={{ color: "var(--accent)" }} />
            <span className="font-label">Step 5 of 7</span>
          </div>
          <h1
            className="text-3xl md:text-4xl font-display mb-2"
            style={{ color: "var(--text)" }}
          >
            Goals
          </h1>
          <p className="mb-6" style={{ color: "var(--text-secondary)" }}>
            What does success look like? Add as many goals as you want.
          </p>

          <div className="flex gap-2 mb-6">
            <input
              ref={inputRef}
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a goal and press Enter..."
              className="input-dark h-12 flex-1"
            />
            <button
              onClick={() => addGoal(inputValue)}
              className="btn-accent flex items-center gap-1 px-4"
            >
              <Plus className="w-4 h-4" />
              Add
            </button>
          </div>

          <button
            onClick={() => setShowExamples(!showExamples)}
            className="flex items-center gap-2 text-sm mb-4 hover:underline"
            style={{ color: "var(--accent-light)" }}
          >
            <Lightbulb className="w-4 h-4" />
            {showExamples ? "Hide examples" : "Need inspiration? See examples"}
          </button>

          <AnimatePresence>
            {showExamples && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                className="overflow-hidden mb-4"
              >
                <div className="flex flex-wrap gap-2">
                  {GOAL_EXAMPLES.map((example) => (
                    <button
                      key={example}
                      onClick={() => addGoal(example)}
                      className="tag-pill hover:brightness-125 transition-all cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      {example}
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          <div className="space-y-2 min-h-[120px]">
            <AnimatePresence mode="popLayout">
              {goals.length === 0 && (
                <motion.p
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="text-center py-8"
                  style={{ color: "var(--text-secondary)" }}
                >
                  No goals added yet. Start typing above or click an example.
                </motion.p>
              )}
              {goals.map((goal, index) => (
                <motion.div
                  key={goal}
                  layout
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20, scale: 0.9 }}
                  className="flex items-center justify-between p-3 rounded-xl"
                  style={{ background: "var(--surface-solid)", border: "1px solid var(--border)" }}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className="font-mono-data text-sm"
                      style={{ color: "var(--accent)" }}
                    >
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <span style={{ color: "var(--text)" }}>{goal}</span>
                  </div>
                  <button
                    onClick={() => removeGoal(index)}
                    className="p-1 rounded-lg hover:bg-red-500/10 transition-colors"
                  >
                    <X className="w-4 h-4" style={{ color: "var(--rose)" }} />
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>

          {goals.length > 0 && (
            <p className="text-sm mt-3" style={{ color: "var(--text-secondary)" }}>
              {goals.length} goal{goals.length !== 1 ? "s" : ""} added
            </p>
          )}

          <div className="flex justify-between mt-10">
            <button
              onClick={() => navigate("/details")}
              className="btn-secondary flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
            <button
              onClick={() => navigate("/habits")}
              className="btn-accent flex items-center gap-2 py-4 px-8 text-base"
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
