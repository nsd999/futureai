import { motion } from "framer-motion";
import { ArrowRight, ArrowLeft, Repeat, Plus, X } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import { useStore } from "@/store/useStore";

const DEFAULT_HABITS = [
  { key: "sleepHours", label: "Hours of sleep per night", placeholder: "e.g., 7" },
  { key: "exerciseFrequency", label: "Exercise frequency", placeholder: "e.g., 3x per week" },
  { key: "readingFrequency", label: "Reading frequency", placeholder: "e.g., Daily" },
  { key: "learningFrequency", label: "Learning frequency", placeholder: "e.g., Weekly courses" },
  { key: "gamingFrequency", label: "Gaming frequency", placeholder: "e.g., Occasional" },
  { key: "socialMediaUsage", label: "Social media usage", placeholder: "e.g., 2 hours/day" },
  { key: "contentCreationFrequency", label: "Content creation frequency", placeholder: "e.g., Weekly" },
  { key: "savingsHabit", label: "Savings habit", placeholder: "e.g., 20% of income" },
  { key: "dietQuality", label: "Diet quality", placeholder: "e.g., Mostly healthy" },
  { key: "dailyRoutine", label: "Daily routine", placeholder: "e.g., Morning person, structured" },
];

export default function HabitsPage() {
  const navigate = useNavigate();
  const { habits, setHabits } = useStore();
  const [customHabits, setCustomHabits] = useState<Array<{ key: string; value: string }>>([]);
  const [newHabitLabel, setNewHabitLabel] = useState("");
  const [newHabitValue, setNewHabitValue] = useState("");

  const updateHabit = (key: string, value: string) => {
    setHabits({ ...habits, [key]: value });
  };

  const addCustomHabit = () => {
    if (newHabitLabel.trim() && newHabitValue.trim()) {
      const key = `custom_${Date.now()}`;
      setCustomHabits([...customHabits, { key, value: newHabitValue.trim() }]);
      setHabits({ ...habits, [key]: newHabitValue.trim() });
      setNewHabitLabel("");
      setNewHabitValue("");
    }
  };

  const removeCustomHabit = (key: string) => {
    setCustomHabits(customHabits.filter((h) => h.key !== key));
    const newHabits = { ...habits };
    delete newHabits[key];
    setHabits(newHabits);
  };

  return (
    <div className="min-h-screen flex items-start justify-center relative z-10 px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.175, 0.885, 0.32, 1.275] }}
        className="w-full max-w-3xl"
      >
        <div className="card-surface p-8 md:p-10">
          <div className="flex items-center gap-3 mb-2">
            <Repeat className="w-6 h-6" style={{ color: "var(--accent)" }} />
            <span className="font-label">Step 6 of 7</span>
          </div>
          <h1
            className="text-3xl md:text-4xl font-display mb-6"
            style={{ color: "var(--text)" }}
          >
            Current Habits
          </h1>

          <div className="space-y-4">
            {DEFAULT_HABITS.map((habit) => (
              <motion.div
                key={habit.key}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: DEFAULT_HABITS.indexOf(habit) * 0.05 }}
              >
                <label className="font-label block mb-2">{habit.label}</label>
                <input
                  type="text"
                  value={(habits[habit.key] as string) ?? ""}
                  onChange={(e) => updateHabit(habit.key, e.target.value)}
                  placeholder={habit.placeholder}
                  className="input-dark h-12"
                />
              </motion.div>
            ))}

            {customHabits.map((habit) => (
              <motion.div
                key={habit.key}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="flex items-end gap-2"
              >
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <label className="font-label">Custom Habit</label>
                    <button
                      onClick={() => removeCustomHabit(habit.key)}
                      className="p-1 rounded hover:bg-red-500/10"
                    >
                      <X className="w-3 h-3" style={{ color: "var(--rose)" }} />
                    </button>
                  </div>
                  <input
                    type="text"
                    value={habit.value}
                    onChange={(e) => updateHabit(habit.key, e.target.value)}
                    className="input-dark h-12"
                  />
                </div>
              </motion.div>
            ))}

            <div className="pt-4 border-t" style={{ borderColor: "var(--border)" }}>
              <p className="font-label mb-3" style={{ color: "var(--accent-light)" }}>
                Add Custom Habit
              </p>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={newHabitLabel}
                  onChange={(e) => setNewHabitLabel(e.target.value)}
                  placeholder="Habit name (e.g., Meditation)"
                  className="input-dark h-12 flex-1"
                />
                <input
                  type="text"
                  value={newHabitValue}
                  onChange={(e) => setNewHabitValue(e.target.value)}
                  placeholder="Frequency"
                  className="input-dark h-12 flex-1"
                />
                <button
                  onClick={addCustomHabit}
                  className="btn-accent px-4"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>

          <div className="flex justify-between mt-10">
            <button
              onClick={() => navigate("/goals")}
              className="btn-secondary flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
            <button
              onClick={() => navigate("/personality")}
              className="btn-accent flex items-center gap-2 py-4 px-8 text-base"
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
