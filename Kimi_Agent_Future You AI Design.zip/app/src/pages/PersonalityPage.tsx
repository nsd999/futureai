import { motion } from "framer-motion";
import { ArrowRight, ArrowLeft, Brain, AlertCircle } from "lucide-react";
import { useNavigate } from "react-router";
import { useStore } from "@/store/useStore";

const TEXT_FIELDS = [
  { key: "biggestStrength", label: "Biggest strength", placeholder: "e.g., Persistence" },
  { key: "biggestWeakness", label: "Biggest weakness", placeholder: "e.g., Perfectionism" },
  { key: "greatestFear", label: "Greatest fear", placeholder: "e.g., Not living up to potential" },
  { key: "mostImportantValue", label: "Most important value", placeholder: "e.g., Integrity" },
  { key: "mostAdmiredPerson", label: "Most admired person", placeholder: "e.g., A family member, public figure" },
  { key: "procrastinationCause", label: "What causes procrastination?", placeholder: "e.g., Fear of failure, overwhelm" },
  { key: "motivationCause", label: "What causes motivation?", placeholder: "e.g., Progress, recognition" },
  { key: "decisionStyle", label: "How are decisions usually made?", placeholder: "e.g., Gut feeling, research" },
];

export default function PersonalityPage() {
  const navigate = useNavigate();
  const { personality, setPersonality } = useStore();

  const isValid = personality.biggestStrength.length > 0;

  return (
    <div className="min-h-screen flex items-start justify-center relative z-10 px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.175, 0.885, 0.32, 1.275] }}
        className="w-full max-w-3xl"
      >
        <div className="card-surface p-8 md:p-10">
          <div className="flex items-center gap-3 mb-2">
            <Brain className="w-6 h-6" style={{ color: "var(--accent)" }} />
            <span className="font-label">Step 7 of 7</span>
          </div>
          <h1
            className="text-3xl md:text-4xl font-display mb-6"
            style={{ color: "var(--text)" }}
          >
            Personality Assessment
          </h1>

          <div className="space-y-4">
            {TEXT_FIELDS.map((field, index) => (
              <motion.div
                key={field.key}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <label className="font-label block mb-2">
                  {field.label}
                  {field.key === "biggestStrength" && (
                    <span style={{ color: "var(--accent)" }}> *</span>
                  )}
                </label>
                <input
                  type="text"
                  value={personality[field.key as keyof typeof personality]}
                  onChange={(e) =>
                    setPersonality({ [field.key]: e.target.value })
                  }
                  placeholder={field.placeholder}
                  className="input-dark h-12"
                />
              </motion.div>
            ))}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
              >
                <label className="font-label block mb-2">Risk Tolerance</label>
                <div className="flex gap-2">
                  {(["low", "medium", "high"] as const).map((level) => (
                    <button
                      key={level}
                      onClick={() => setPersonality({ riskTolerance: level })}
                      className="flex-1 py-3 rounded-xl text-sm font-medium capitalize transition-all"
                      style={{
                        background:
                          personality.riskTolerance === level
                            ? "var(--accent)"
                            : "var(--surface-solid)",
                        color:
                          personality.riskTolerance === level
                            ? "white"
                            : "var(--text-secondary)",
                        border:
                          personality.riskTolerance === level
                            ? "1px solid var(--accent)"
                            : "1px solid var(--border)",
                      }}
                    >
                      {level}
                    </button>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.45 }}
              >
                <label className="font-label block mb-2">Social Style</label>
                <div className="flex gap-2">
                  {(["introvert", "extrovert", "ambivert"] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => setPersonality({ introvertExtrovert: style })}
                      className="flex-1 py-3 rounded-xl text-sm font-medium capitalize transition-all"
                      style={{
                        background:
                          personality.introvertExtrovert === style
                            ? "var(--teal)"
                            : "var(--surface-solid)",
                        color:
                          personality.introvertExtrovert === style
                            ? "white"
                            : "var(--text-secondary)",
                        border:
                          personality.introvertExtrovert === style
                            ? "1px solid var(--teal)"
                            : "1px solid var(--border)",
                      }}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5 }}
              >
                <label className="font-label block mb-2">Thinking Style</label>
                <div className="flex gap-2">
                  {(["long-term", "short-term", "balanced"] as const).map(
                    (style) => (
                      <button
                        key={style}
                        onClick={() => setPersonality({ thinkingStyle: style })}
                        className="flex-1 py-3 rounded-xl text-sm font-medium capitalize transition-all"
                        style={{
                          background:
                            personality.thinkingStyle === style
                              ? "var(--accent)"
                              : "var(--surface-solid)",
                          color:
                            personality.thinkingStyle === style
                              ? "white"
                              : "var(--text-secondary)",
                          border:
                            personality.thinkingStyle === style
                              ? "1px solid var(--accent)"
                              : "1px solid var(--border)",
                        }}
                      >
                        {style}
                      </button>
                    )
                  )}
                </div>
              </motion.div>
            </div>

            {!isValid && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex items-center gap-2 mt-4"
                style={{ color: "var(--warning)" }}
              >
                <AlertCircle className="w-4 h-4" />
                <span className="text-sm">
                  Please fill in at least your biggest strength to continue.
                </span>
              </motion.div>
            )}
          </div>

          <div className="flex justify-between mt-10">
            <button
              onClick={() => navigate("/habits")}
              className="btn-secondary flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>
            <button
              onClick={() => navigate("/analyzing")}
              disabled={!isValid}
              className="btn-accent flex items-center gap-2 py-4 px-8 text-base disabled:opacity-40 disabled:cursor-not-allowed"
            >
              Generate My Future
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
