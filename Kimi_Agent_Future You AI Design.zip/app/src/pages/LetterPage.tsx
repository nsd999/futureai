import { motion } from "framer-motion";
import { ArrowLeft, Mail, Feather } from "lucide-react";
import { useNavigate } from "react-router";
import { useStore } from "@/store/useStore";

export default function LetterPage() {
  const navigate = useNavigate();
  const { letter } = useStore();

  if (!letter) {
    return (
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <div className="text-center">
          <Mail className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--accent)" }} />
          <p style={{ color: "var(--text-secondary)" }}>No letter generated yet.</p>
          <button onClick={() => navigate("/futures")} className="btn-accent mt-4">
            Back to Futures
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative z-10 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <button
            onClick={() => navigate("/futures")}
            className="flex items-center gap-2 text-sm mb-6 hover:underline"
            style={{ color: "var(--text-secondary)" }}
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Futures
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="card-surface p-8 md:p-12 relative overflow-hidden"
        >
          <div
            className="absolute top-0 left-0 w-full h-1"
            style={{
              background: "linear-gradient(90deg, var(--accent), var(--teal), var(--accent))",
            }}
          />

          <div className="flex items-center gap-3 mb-8">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: "var(--accent-glow)" }}
            >
              <Feather className="w-5 h-5" style={{ color: "var(--accent)" }} />
            </div>
            <div>
              <span className="font-label">Future Letter</span>
              <h1
                className="text-2xl md:text-3xl font-display"
                style={{ color: "var(--text)" }}
              >
                {letter.title}
              </h1>
            </div>
          </div>

          <div
            className="prose prose-invert max-w-none"
            style={{ color: "var(--text)" }}
          >
            {letter.content.split("\n\n").map((paragraph, index) => {
              const isHeading = paragraph.startsWith("ABOUT") ||
                paragraph.startsWith("THE VICTORIES") ||
                paragraph.startsWith("THE FAILURES") ||
                paragraph.startsWith("WHAT I'D DO") ||
                paragraph.startsWith("THE UNEXPECTED") ||
                paragraph.startsWith("MY ADVICE") ||
                paragraph.startsWith("FINAL THOUGHTS");

              const isListItem = paragraph.startsWith("- ");
              const isNumbered = /^\d+\./.test(paragraph);

              if (isHeading) {
                return (
                  <h3
                    key={index}
                    className="text-lg font-medium mt-8 mb-4"
                    style={{ color: "var(--accent-light)" }}
                  >
                    {paragraph}
                  </h3>
                );
              }

              if (isListItem) {
                return (
                  <li
                    key={index}
                    className="ml-4 mb-2 text-sm leading-relaxed"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {paragraph.slice(2)}
                  </li>
                );
              }

              if (isNumbered) {
                return (
                  <li
                    key={index}
                    className="ml-4 mb-2 text-sm leading-relaxed"
                    style={{ color: "var(--text-secondary)" }}
                  >
                    {paragraph}
                  </li>
                );
              }

              return (
                <p
                  key={index}
                  className="mb-4 text-sm leading-relaxed"
                  style={{ color: "var(--text-secondary)" }}
                >
                  {paragraph}
                </p>
              );
            })}
          </div>

          <div
            className="mt-10 pt-6 border-t flex items-center gap-2"
            style={{ borderColor: "var(--border)" }}
          >
            <div
              className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{ background: "var(--accent-glow)" }}
            >
              <span className="text-sm" style={{ color: "var(--accent)" }}>
                {letter.title?.includes("Age") ? letter.title.match(/\d+/)?.[0] : "F"}
              </span>
            </div>
            <span className="text-sm" style={{ color: "var(--text-secondary)" }}>
              Written by your future self
            </span>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
