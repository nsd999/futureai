import { motion } from "framer-motion";
import { Copy, ArrowRight, CheckCircle, ClipboardList } from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";

const IMPORT_PROMPT = `You are helping me import context from one AI assistant to another.

Your job is to go through our past conversations and sum up what you know about me.

Avoid using first-person pronouns (I, my, me, mine).
Avoid using second-person pronouns (you, your, yours).
Refer to the individual as "the user."
Preserve wording verbatim whenever possible.

Categories:
1. Demographics Information
2. Interests and Preferences
3. Relationships
4. Dated Events, Projects and Plans
5. Instructions

Format:
The user's name is <name>

Evidence:
User said "<quote>"

Date:
[YYYY-MM-DD]

Output everything as a structured text block.

Finally complete:
My AI name is: <assistant name>`;

export default function ImportContextPage() {
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(IMPORT_PROMPT);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {
      const textarea = document.createElement("textarea");
      textarea.value = IMPORT_PROMPT;
      document.body.appendChild(textarea);
      textarea.select();
      document.execCommand("copy");
      document.body.removeChild(textarea);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative z-10 px-4 py-12">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.175, 0.885, 0.32, 1.275] }}
        className="w-full max-w-3xl"
      >
        <div className="card-surface p-8 md:p-10">
          <div className="flex items-center gap-3 mb-2">
            <ClipboardList className="w-6 h-6" style={{ color: "var(--accent)" }} />
            <span className="font-label">Step 2 of 7</span>
          </div>
          <h1
            className="text-3xl md:text-4xl font-display mb-6"
            style={{ color: "var(--text)" }}
          >
            Import Context
          </h1>

          <div className="space-y-6 mb-8" style={{ color: "var(--text-secondary)" }}>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <span
                  className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-sm font-medium"
                  style={{ background: "var(--accent-glow)", color: "var(--accent)" }}
                >
                  1
                </span>
                <p>Copy the prompt below.</p>
              </div>
              <div className="flex items-start gap-3">
                <span
                  className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-sm font-medium"
                  style={{ background: "var(--accent-glow)", color: "var(--accent)" }}
                >
                  2
                </span>
                <p>Paste it into ChatGPT, Claude, Gemini, Grok, DeepSeek, Perplexity, or another AI assistant that contains historical conversations.</p>
              </div>
              <div className="flex items-start gap-3">
                <span
                  className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-sm font-medium"
                  style={{ background: "var(--accent-glow)", color: "var(--accent)" }}
                >
                  3
                </span>
                <p>Receive the generated user summary.</p>
              </div>
              <div className="flex items-start gap-3">
                <span
                  className="flex-shrink-0 w-7 h-7 rounded-full flex items-center justify-center text-sm font-medium"
                  style={{ background: "var(--accent-glow)", color: "var(--accent)" }}
                >
                  4
                </span>
                <p>Paste the generated summary into Future You AI.</p>
              </div>
            </div>
          </div>

          <div className="relative mb-8">
            <div
              className="rounded-xl p-6 font-mono text-sm overflow-auto max-h-96"
              style={{
                background: "var(--slate)",
                border: "1px solid var(--border)",
                color: "var(--text)",
                lineHeight: 1.7,
              }}
            >
              <pre className="whitespace-pre-wrap">{IMPORT_PROMPT}</pre>
            </div>
            <button
              onClick={handleCopy}
              className="absolute top-4 right-4 flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all"
              style={{
                background: copied ? "var(--teal)" : "var(--slate-lighter)",
                color: "white",
              }}
            >
              {copied ? (
                <>
                  <CheckCircle className="w-4 h-4" />
                  Copied
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copy Prompt
                </>
              )}
            </button>
          </div>

          <div className="flex justify-end">
            <button
              onClick={() => navigate("/profile")}
              className="btn-accent flex items-center gap-2 py-4 px-8 text-base"
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
