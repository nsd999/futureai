import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowLeft,
  Send,
  Sparkles,
  User,
  Trash2,
  Bot,
} from "lucide-react";
import { useNavigate } from "react-router";
import { useState, useRef, useEffect } from "react";
import { useStore } from "@/store/useStore";
import { trpc } from "@/providers/trpc";

const QUICK_QUESTIONS = [
  "What should I focus on right now?",
  "What mistake should I avoid?",
  "Did the business succeed?",
  "How did finances improve?",
  "Which skill changed everything?",
  "What habit mattered most?",
  "What was regretted most?",
  "What should I stop immediately?",
];

function TypingIndicator() {
  return (
    <div className="flex items-center gap-1.5 px-4 py-3">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="w-2 h-2 rounded-full"
          style={{ background: "var(--accent)" }}
          animate={{
            scale: [0.4, 1, 0.4],
            opacity: [0.4, 1, 0.4],
          }}
          transition={{
            duration: 0.6,
            repeat: Infinity,
            delay: i * 0.15,
          }}
        />
      ))}
    </div>
  );
}

export default function ChatPage() {
  const navigate = useNavigate();
  const { chatMessages, isTyping, addChatMessage, setIsTyping, currentRunId } =
    useStore();
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatMutation = trpc.chat.send.useMutation();
  const clearMutation = trpc.chat.clearHistory.useMutation();
  const utils = trpc.useUtils();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [chatMessages, isTyping]);

  const handleSend = async (content: string) => {
    if (!content.trim() || isTyping) return;

    addChatMessage({ role: "user", content: content.trim() });
    setInput("");
    setIsTyping(true);

    try {
      const result = await chatMutation.mutateAsync({
        content: content.trim(),
        runId: currentRunId ?? undefined,
      });

      addChatMessage({ role: "assistant", content: result.response });
    } catch {
      addChatMessage({
        role: "assistant",
        content:
          "Hey, I'm having trouble connecting right now. But let me tell you this - whatever you're going through, keep going. The future version of you is rooting for you.",
      });
    } finally {
      setIsTyping(false);
    }
  };

  const handleClear = async () => {
    if (confirm("Clear all chat messages?")) {
      try {
        await clearMutation.mutateAsync();
        utils.chat.history.invalidate();
      } catch {
        // ignore
      }
      useStore.setState({ chatMessages: [] });
    }
  };

  const hasMessages = chatMessages.length > 0;

  return (
    <div className="h-screen flex flex-col relative z-10">
      <div
        className="flex items-center justify-between px-4 md:px-8 py-4 border-b"
        style={{ borderColor: "var(--border)" }}
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigate("/futures")}
            className="p-2 rounded-lg hover:bg-white/5 transition-colors"
          >
            <ArrowLeft className="w-5 h-5" style={{ color: "var(--text-secondary)" }} />
          </button>
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, var(--teal), var(--accent))",
            }}
          >
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div>
            <h1
              className="text-base font-medium"
              style={{ color: "var(--text)" }}
            >
              Future Self
            </h1>
            <p className="text-xs" style={{ color: "var(--text-secondary)" }}>
              {isTyping ? "Typing..." : "Online"}
            </p>
          </div>
        </div>
        {hasMessages && (
          <button
            onClick={handleClear}
            className="p-2 rounded-lg hover:bg-white/5 transition-colors"
            title="Clear chat"
          >
            <Trash2 className="w-4 h-4" style={{ color: "var(--text-secondary)" }} />
          </button>
        )}
      </div>

      <div
        className="flex-1 overflow-y-auto px-4 md:px-8 py-6 space-y-4"
        style={{ background: "transparent" }}
      >
        {!hasMessages && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col items-center justify-center h-full text-center"
          >
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
              style={{
                background: "linear-gradient(135deg, var(--accent), var(--teal))",
              }}
            >
              <Bot className="w-8 h-8 text-white" />
            </div>
            <h2
              className="text-xl font-display mb-2"
              style={{ color: "var(--text)" }}
            >
              Hey, it's good to hear from the younger version.
            </h2>
            <p className="max-w-md mb-8" style={{ color: "var(--text-secondary)" }}>
              I'm your future self. I've already lived through the next decade. Ask me anything - I'll be honest with you.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-w-lg w-full">
              {QUICK_QUESTIONS.slice(0, 6).map((q) => (
                <button
                  key={q}
                  onClick={() => handleSend(q)}
                  className="text-left px-4 py-3 rounded-xl text-sm transition-all hover:brightness-125"
                  style={{
                    background: "var(--surface-solid)",
                    border: "1px solid var(--border)",
                    color: "var(--text-secondary)",
                  }}
                >
                  {q}
                </button>
              ))}
            </div>
          </motion.div>
        )}

        <AnimatePresence>
          {chatMessages.map((msg, index) => (
            <motion.div
              key={index}
              initial={
                msg.role === "assistant"
                  ? { opacity: 0, y: 10 }
                  : { opacity: 0, x: 20 }
              }
              animate={{ opacity: 1, x: 0, y: 0 }}
              transition={{ duration: 0.3 }}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
            >
              <div
                className={`max-w-[85%] px-5 py-4 rounded-2xl ${
                  msg.role === "user"
                    ? "rounded-br-sm"
                    : "rounded-bl-sm"
                }`}
                style={
                  msg.role === "user"
                    ? {
                        background: "var(--accent)",
                        color: "white",
                      }
                    : {
                        background: "var(--surface-solid)",
                        border: "1px solid var(--border)",
                        color: "var(--text)",
                      }
                }
              >
                {msg.role === "assistant" && (
                  <div className="flex items-center gap-2 mb-2">
                    <div
                      className="w-6 h-6 rounded-lg flex items-center justify-center"
                      style={{
                        background:
                          "linear-gradient(135deg, var(--teal), var(--accent))",
                      }}
                    >
                      <Sparkles className="w-3 h-3 text-white" />
                    </div>
                    <span
                      className="text-xs font-medium"
                      style={{ color: "var(--accent-light)" }}
                    >
                      Future You
                    </span>
                  </div>
                )}
                <p className="text-sm leading-relaxed whitespace-pre-wrap">
                  {msg.content}
                </p>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>

        {isTyping && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex justify-start"
          >
            <div
              className="rounded-2xl rounded-bl-sm px-4"
              style={{
                background: "var(--surface-solid)",
                border: "1px solid var(--border)",
              }}
            >
              <TypingIndicator />
            </div>
          </motion.div>
        )}

        <div ref={messagesEndRef} />
      </div>

      <div
        className="px-4 md:px-8 py-4 border-t"
        style={{ borderColor: "var(--border)", background: "rgba(26, 29, 35, 0.8)" }}
      >
        <div className="flex items-center gap-3 max-w-3xl mx-auto">
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
            style={{ background: "var(--slate-lighter)" }}
          >
            <User className="w-4 h-4" style={{ color: "var(--text-secondary)" }} />
          </div>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend(input);
              }
            }}
            placeholder="Ask your future self anything..."
            className="input-dark h-12 flex-1"
            disabled={isTyping}
          />
          <button
            onClick={() => handleSend(input)}
            disabled={!input.trim() || isTyping}
            className="w-12 h-12 rounded-xl flex items-center justify-center transition-all disabled:opacity-30"
            style={{ background: "var(--accent)" }}
          >
            <Send className="w-5 h-5 text-white" />
          </button>
        </div>
      </div>
    </div>
  );
}
