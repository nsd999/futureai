import { motion } from "framer-motion";
import { ArrowLeft, AlertOctagon, AlertTriangle, ShieldCheck, TrendingUp } from "lucide-react";
import { useNavigate } from "react-router";
import { useStore } from "@/store/useStore";

export default function RegretsPage() {
  const navigate = useNavigate();
  const { regretAnalysis } = useStore();

  if (!regretAnalysis) {
    return (
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <div className="text-center">
          <AlertOctagon className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--rose)" }} />
          <p style={{ color: "var(--text-secondary)" }}>No regret analysis generated yet.</p>
          <button onClick={() => navigate("/futures")} className="btn-accent mt-4">
            Back to Futures
          </button>
        </div>
      </div>
    );
  }

  const lines = regretAnalysis.content.split("\n").filter((l) => l.trim());
  const regrets: Array<{ number: string; text: string; probability: string; severity: string; action: string }> = [];
  let currentRegret: Partial<(typeof regrets)[0]> = {};

  for (const line of lines) {
    const numMatch = line.match(/^(\d+)\.\s*(.+)/);
    if (numMatch) {
      if (currentRegret.text) regrets.push(currentRegret as (typeof regrets)[0]);
      currentRegret = { number: numMatch[1], text: numMatch[2] };
    } else if (line.includes("Probability:")) {
      currentRegret.probability = line.replace("Probability:", "").trim();
    } else if (line.includes("Severity:")) {
      currentRegret.severity = line.replace("Severity:", "").trim();
    } else if (line.includes("Prevention:") || line.includes("Preventive")) {
      currentRegret.action = line.replace("Prevention:", "").replace("Preventive actions:", "").trim();
    }
  }
  if (currentRegret.text) regrets.push(currentRegret as (typeof regrets)[0]);

  const meta = (regretAnalysis.metadata as Record<string, unknown>) ?? {};

  return (
    <div className="min-h-screen relative z-10 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <button
            onClick={() => navigate("/futures")}
            className="flex items-center gap-2 text-sm mb-6 hover:underline"
            style={{ color: "var(--text-secondary)" }}
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Futures
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div
            className="rounded-2xl p-8 mb-6"
            style={{
              background: "var(--rose-glow)",
              border: "1px solid rgba(196, 91, 106, 0.2)",
            }}
          >
            <div className="flex items-center gap-3 mb-2">
              <AlertTriangle className="w-6 h-6" style={{ color: "var(--rose)" }} />
              <span className="font-label" style={{ color: "var(--rose)" }}>
                WAKE-UP CALL
              </span>
            </div>
            <h1
              className="text-2xl md:text-3xl font-display mb-2"
              style={{ color: "var(--text)" }}
            >
              {regretAnalysis.title}
            </h1>
            <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
              Based on your current trajectory, if nothing changes, these are the regrets
              you would have in 10 years. The good news: every single one is preventable.
            </p>
          </div>

          <div className="space-y-4">
            {regrets.map((regret, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.1 + index * 0.05 }}
                className="card-surface p-6"
              >
                <div className="flex items-start gap-4">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{ background: "var(--rose-glow)" }}
                  >
                    <span
                      className="font-mono-data text-sm font-medium"
                      style={{ color: "var(--rose)" }}
                    >
                      {regret.number}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p
                      className="text-sm font-medium mb-3"
                      style={{ color: "var(--text)" }}
                    >
                      {regret.text}
                    </p>
                    <div className="flex flex-wrap gap-3">
                      {regret.probability && (
                        <span
                          className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg"
                          style={{
                            background: "var(--accent-glow)",
                            color: "var(--accent-light)",
                          }}
                        >
                          <TrendingUp className="w-3 h-3" />
                          {regret.probability}
                        </span>
                      )}
                      {regret.severity && (
                        <span
                          className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg"
                          style={{
                            background: "var(--rose-glow)",
                            color: "var(--rose-light)",
                          }}
                        >
                          <AlertTriangle className="w-3 h-3" />
                          {regret.severity}
                        </span>
                      )}
                      {regret.action && (
                        <span
                          className="flex items-center gap-1 text-xs px-2 py-1 rounded-lg"
                          style={{
                            background: "var(--teal-glow)",
                            color: "var(--teal-light)",
                          }}
                        >
                          <ShieldCheck className="w-3 h-3" />
                          {regret.action}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {meta.preventable as boolean && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="mt-8 p-6 rounded-2xl text-center"
              style={{
                background: "var(--teal-glow)",
                border: "1px solid rgba(74, 155, 142, 0.2)",
              }}
            >
              <ShieldCheck className="w-8 h-8 mx-auto mb-3" style={{ color: "var(--teal)" }} />
              <h3 className="text-lg font-medium mb-2" style={{ color: "var(--text)" }}>
                Every regret is preventable.
              </h3>
              <p className="text-sm" style={{ color: "var(--text-secondary)" }}>
                Focus on the top 3 items this month. Not everything at once. Just three
                small steps that move you in a different direction.
              </p>
              <button
                onClick={() => navigate("/chat")}
                className="btn-accent mt-4"
              >
                Talk to Your Future Self
              </button>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
