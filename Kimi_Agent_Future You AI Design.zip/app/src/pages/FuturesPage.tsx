import { motion, AnimatePresence } from "framer-motion";
import {
  TrendingUp,
  TrendingDown,
  Minus,
  ChevronDown,
  ChevronUp,
  Sparkles,
  Award,
  AlertTriangle,
  BookOpen,
  Briefcase,
  Heart,
  Users,
  Zap,
  Star,
  MessageCircle,
  Mail,
  Newspaper,
  Linkedin,
  AlertOctagon,
} from "lucide-react";
import { useNavigate } from "react-router";
import { useState } from "react";
import { useStore } from "@/store/useStore";
import ScoreRing from "@/components/ScoreRing";

function FutureCard({
  future,
  index,
  isExpanded,
  onToggle,
}: {
  future: ReturnType<typeof useStore.getState>["futures"][0];
  index: number;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const colors = {
    best: {
      border: "var(--teal)",
      bg: "var(--teal-glow)",
      icon: TrendingUp,
      label: "Best Possible Future",
      badge: "Optimistic Path",
    },
    likely: {
      border: "var(--accent)",
      bg: "var(--accent-glow)",
      icon: Minus,
      label: "Most Likely Future",
      badge: "Realistic Path",
    },
    worst: {
      border: "var(--rose)",
      bg: "var(--rose-glow)",
      icon: TrendingDown,
      label: "Worst Possible Future",
      badge: "Cautionary Path",
    },
  };

  const cfg = colors[future.scenarioKey as keyof typeof colors] ?? colors.likely;
  const Icon = cfg.icon;

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.15, duration: 0.5 }}
      className="rounded-2xl overflow-hidden"
      style={{
        border: `2px solid ${cfg.border}`,
        background: cfg.bg,
      }}
    >
      <button
        onClick={onToggle}
        className="w-full p-6 flex items-center gap-4 text-left"
      >
        <div
          className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0"
          style={{ background: cfg.border }}
        >
          <Icon className="w-6 h-6 text-white" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <span
              className="text-xs font-medium px-2 py-0.5 rounded-full"
              style={{ background: cfg.border, color: "white" }}
            >
              {cfg.badge}
            </span>
          </div>
          <h3
            className="text-xl font-display truncate"
            style={{ color: "var(--text)" }}
          >
            {cfg.label}
          </h3>
        </div>
        {isExpanded ? (
          <ChevronUp className="w-5 h-5 flex-shrink-0" style={{ color: "var(--text-secondary)" }} />
        ) : (
          <ChevronDown className="w-5 h-5 flex-shrink-0" style={{ color: "var(--text-secondary)" }} />
        )}
      </button>

      <AnimatePresence>
        {isExpanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: "auto", opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden"
          >
            <div
              className="px-6 pb-6 space-y-5"
              style={{ borderTop: `1px solid ${cfg.border}40` }}
            >
              <div className="pt-5">
                <p
                  className="text-sm leading-relaxed italic"
                  style={{ color: "var(--text-secondary)" }}
                >
                  {future.narrative?.slice(0, 300)}...
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <DetailBlock icon={Briefcase} label="Career" text={future.career} color="var(--accent)" />
                <DetailBlock icon={Heart} label="Health" text={future.health} color="var(--teal)" />
                <DetailBlock icon={Users} label="Relationships" text={future.relationships} color="var(--accent-light)" />
                <DetailBlock icon={Star} label="Lifestyle" text={future.lifestyle} color="var(--accent)" />
              </div>

              {future.majorAchievements && future.majorAchievements.length > 0 && (
                <div>
                  <h4 className="font-label mb-3 flex items-center gap-2">
                    <Award className="w-4 h-4" style={{ color: "var(--accent)" }} />
                    Major Achievements
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {future.majorAchievements.map((a, i) => (
                      <span key={i} className="tag-pill">
                        {a}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {future.majorMistakes && future.majorMistakes.length > 0 && (
                <div>
                  <h4 className="font-label mb-3 flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" style={{ color: "var(--warning)" }} />
                    Major Mistakes
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {future.majorMistakes.map((m, i) => (
                      <span
                        key={i}
                        className="px-3 py-1.5 rounded-full text-xs font-medium"
                        style={{
                          background: "var(--rose-glow)",
                          color: "var(--rose-light)",
                        }}
                      >
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {future.skillsAcquired && future.skillsAcquired.length > 0 && (
                <div>
                  <h4 className="font-label mb-3 flex items-center gap-2">
                    <BookOpen className="w-4 h-4" style={{ color: "var(--teal)" }} />
                    Skills Acquired
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {future.skillsAcquired.map((s, i) => (
                      <span
                        key={i}
                        className="px-3 py-1.5 rounded-full text-xs font-medium"
                        style={{
                          background: "var(--teal-glow)",
                          color: "var(--teal-light)",
                        }}
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              <div className="p-4 rounded-xl" style={{ background: "var(--surface-solid)" }}>
                <h4 className="font-label mb-2 flex items-center gap-2">
                  <Zap className="w-4 h-4" style={{ color: "var(--accent)" }} />
                  Lessons Learned
                </h4>
                <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
                  {future.lessonsLearned}
                </p>
              </div>

              {future.regrets && (
                <div className="p-4 rounded-xl" style={{ background: "var(--rose-glow)" }}>
                  <h4 className="font-label mb-2 flex items-center gap-2" style={{ color: "var(--rose)" }}>
                    <AlertTriangle className="w-4 h-4" />
                    Regrets
                  </h4>
                  <p className="text-sm leading-relaxed" style={{ color: "var(--rose-light)" }}>
                    {future.regrets}
                  </p>
                </div>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function DetailBlock({
  icon: Icon,
  label,
  text,
  color,
}: {
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  label: string;
  text: string;
  color: string;
}) {
  return (
    <div className="p-4 rounded-xl" style={{ background: "var(--surface-solid)" }}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4" style={{ color }} />
        <span className="font-label">{label}</span>
      </div>
      <p className="text-sm leading-relaxed" style={{ color: "var(--text-secondary)" }}>
        {text?.slice(0, 200) ?? "Not specified"}
      </p>
    </div>
  );
}

function QuickAction({
  icon: Icon,
  label,
  onClick,
  color,
}: {
  icon: React.ComponentType<{ className?: string; style?: React.CSSProperties }>;
  label: string;
  onClick: () => void;
  color: string;
}) {
  return (
    <motion.button
      whileHover={{ scale: 1.03, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={onClick}
      className="flex flex-col items-center gap-3 p-5 rounded-xl transition-all"
      style={{
        background: "var(--surface-solid)",
        border: "1px solid var(--border)",
      }}
    >
      <div
        className="w-12 h-12 rounded-xl flex items-center justify-center"
        style={{ background: `${color}20` }}
      >
        <Icon className="w-6 h-6" style={{ color }} />
      </div>
      <span className="text-sm font-medium" style={{ color: "var(--text)" }}>
        {label}
      </span>
    </motion.button>
  );
}

export default function FuturesPage() {
  const navigate = useNavigate();
  const { futures, scores } = useStore();
  const [expandedIndex, setExpandedIndex] = useState<number | null>(1);

  if (futures.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <div className="text-center">
          <Sparkles className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--accent)" }} />
          <p style={{ color: "var(--text-secondary)" }}>No futures generated yet.</p>
          <button onClick={() => navigate("/")} className="btn-accent mt-4">
            Start Over
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen relative z-10 px-4 py-8 md:px-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1
            className="text-3xl md:text-4xl font-display mb-2"
            style={{ color: "var(--text)" }}
          >
            Your Three Futures
          </h1>
          <p style={{ color: "var(--text-secondary)" }}>
            Three realistic scenarios based on your profile. Expand each to explore.
          </p>
        </motion.div>

        {scores && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <div className="card-surface p-6">
              <h2 className="font-label mb-4">Analysis Scores</h2>
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                <ScoreRing value={scores.growthPotential} label="Growth" color="var(--accent)" />
                <ScoreRing value={scores.discipline} label="Discipline" color="var(--teal)" />
                <ScoreRing value={scores.careerProjection} label="Career" color="var(--accent-light)" />
                <ScoreRing value={scores.healthProjection} label="Health" color="var(--teal)" />
                <ScoreRing value={scores.financialProjection} label="Finance" color="var(--accent)" />
              </div>
            </div>
          </motion.div>
        )}

        <div className="space-y-4 mb-10">
          {futures.map((future, index) => (
            <FutureCard
              key={future.scenarioKey}
              future={future}
              index={index}
              isExpanded={expandedIndex === index}
              onToggle={() =>
                setExpandedIndex(expandedIndex === index ? null : index)
              }
            />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h2
            className="text-xl font-display mb-4"
            style={{ color: "var(--text)" }}
          >
            Explore More
          </h2>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            <QuickAction
              icon={MessageCircle}
              label="Chat with Future Self"
              onClick={() => navigate("/chat")}
              color="var(--accent)"
            />
            <QuickAction
              icon={Mail}
              label="Future Letter"
              onClick={() => navigate("/letter")}
              color="var(--teal)"
            />
            <QuickAction
              icon={Newspaper}
              label="News Article"
              onClick={() => navigate("/news")}
              color="var(--accent-light)"
            />
            <QuickAction
              icon={Linkedin}
              label="LinkedIn Profile"
              onClick={() => navigate("/linkedin")}
              color="var(--teal)"
            />
            <QuickAction
              icon={AlertOctagon}
              label="Regret Analyzer"
              onClick={() => navigate("/regrets")}
              color="var(--rose)"
            />
          </div>
        </motion.div>
      </div>
    </div>
  );
}
