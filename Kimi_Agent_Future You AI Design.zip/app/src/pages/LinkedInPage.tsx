import { motion } from "framer-motion";
import { ArrowLeft, Linkedin, Award, Briefcase, BookOpen, ThumbsUp } from "lucide-react";
import { useNavigate } from "react-router";
import { useStore } from "@/store/useStore";

export default function LinkedInPage() {
  const navigate = useNavigate();
  const { linkedInProfile } = useStore();

  if (!linkedInProfile) {
    return (
      <div className="min-h-screen flex items-center justify-center relative z-10">
        <div className="text-center">
          <Linkedin className="w-12 h-12 mx-auto mb-4" style={{ color: "var(--accent)" }} />
          <p style={{ color: "var(--text-secondary)" }}>No LinkedIn profile generated yet.</p>
          <button onClick={() => navigate("/futures")} className="btn-accent mt-4">
            Back to Futures
          </button>
        </div>
      </div>
    );
  }

  const lines = linkedInProfile.content.split("\n").filter((l) => l.trim());
  const sections: Record<string, string[]> = {};
  let currentSection = "header";

  for (const line of lines) {
    const upper = line.toUpperCase();
    if (
      upper.startsWith("HEADLINE:") ||
      upper.startsWith("SUMMARY:") ||
      upper.startsWith("CORE SKILLS:") ||
      upper.startsWith("KEY PROJECTS:") ||
      upper.startsWith("ACHIEVEMENTS:") ||
      upper.startsWith("RECOMMENDATIONS:")
    ) {
      currentSection = upper.replace(":", "").toLowerCase().replace(/\s+/g, "_");
      sections[currentSection] = [];
    } else {
      if (!sections[currentSection]) sections[currentSection] = [];
      sections[currentSection].push(line);
    }
  }

  const meta = (linkedInProfile.metadata as Record<string, string>) ?? {};

  const sectionIcons: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
    headline: Briefcase,
    summary: BookOpen,
    core_skills: Award,
    key_projects: Briefcase,
    achievements: Award,
    recommendations: ThumbsUp,
  };

  return (
    <div className="min-h-screen relative z-10 px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <button
            onClick={() => navigate("/futures")}
            className="flex items-center gap-2 text-sm mb-6 hover:underline"
            style={{ color: "var(--text-secondary)" }}
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Futures
          </button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="card-surface overflow-hidden">
            <div
              className="h-32 relative"
              style={{
                background:
                  "linear-gradient(135deg, var(--accent), var(--teal), var(--accent))",
              }}
            >
              <div className="absolute -bottom-12 left-8">
                <div
                  className="w-24 h-24 rounded-full border-4 flex items-center justify-center"
                  style={{
                    borderColor: "var(--slate-light)",
                    background: "var(--slate-lighter)",
                  }}
                >
                  <span
                    className="text-2xl font-medium"
                    style={{ color: "var(--accent)" }}
                  >
                    {linkedInProfile.title?.charAt(0) ?? "U"}
                  </span>
                </div>
              </div>
            </div>

            <div className="pt-16 pb-6 px-8">
              <h1
                className="text-xl font-display mb-1"
                style={{ color: "var(--text)" }}
              >
                {linkedInProfile.title}
              </h1>
              <p className="text-sm mb-4" style={{ color: "var(--text-secondary)" }}>
                {meta.connections ?? "500+"} connections
              </p>

              <div className="flex gap-2 mb-6">
                <span
                  className="px-3 py-1 rounded-full text-xs font-medium"
                  style={{
                    background: "var(--teal-glow)",
                    color: "var(--teal-light)",
                  }}
                >
                  Open to work
                </span>
                <span
                  className="px-3 py-1 rounded-full text-xs font-medium"
                  style={{
                    background: "var(--accent-glow)",
                    color: "var(--accent-light)",
                  }}
                >
                  {meta.industry ?? "Multiple Industries"}
                </span>
              </div>

              {Object.entries(sections).map(([key, sectionLines]) => {
                const Icon = sectionIcons[key] ?? BookOpen;
                const title = key.replace(/_/g, " ").toUpperCase();

                return (
                  <div
                    key={key}
                    className="pt-6 border-t mb-6"
                    style={{ borderColor: "var(--border)" }}
                  >
                    <div className="flex items-center gap-2 mb-4">
                      <Icon className="w-4 h-4" style={{ color: "var(--accent)" }} />
                      <h3
                        className="text-sm font-medium"
                        style={{ color: "var(--accent-light)" }}
                      >
                        {title}
                      </h3>
                    </div>
                    <div className="space-y-2">
                      {sectionLines.map((line, i) => {
                        if (line.startsWith("• ")) {
                          return (
                            <li
                              key={i}
                              className="ml-4 text-sm leading-relaxed"
                              style={{ color: "var(--text-secondary)" }}
                            >
                              {line.slice(2)}
                            </li>
                          );
                        }
                        if (line.startsWith('"') || line.startsWith("\"")) {
                          return (
                            <blockquote
                              key={i}
                              className="pl-4 border-l-2 text-sm italic leading-relaxed my-3"
                              style={{
                                borderColor: "var(--accent)",
                                color: "var(--text)",
                              }}
                            >
                              {line}
                            </blockquote>
                          );
                        }
                        return (
                          <p
                            key={i}
                            className="text-sm leading-relaxed"
                            style={{ color: "var(--text-secondary)" }}
                          >
                            {line}
                          </p>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
