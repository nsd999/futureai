import { motion } from "framer-motion";
import { Sparkles, ArrowRight, FileText } from "lucide-react";
import { useNavigate } from "react-router";
import { useStore } from "@/store/useStore";

export default function WelcomePage() {
  const navigate = useNavigate();
  const resetOnboarding = useStore((s) => s.resetOnboarding);

  const handleStartFresh = () => {
    resetOnboarding();
    navigate("/import");
  };

  const handleContinue = () => {
    navigate("/import");
  };

  return (
    <div className="min-h-screen flex items-center justify-center relative z-10 px-4">
      <motion.div
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, ease: [0.175, 0.885, 0.32, 1.275] }}
        className="w-full max-w-2xl"
      >
        <div className="card-surface p-8 md:p-12">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
            className="flex items-center justify-center mb-8"
          >
            <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[var(--accent)] to-[var(--teal)] flex items-center justify-center">
              <Sparkles className="w-8 h-8 text-white" />
            </div>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-4xl md:text-5xl font-display text-center mb-4"
            style={{ color: "var(--text)" }}
          >
            Future You AI
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="text-lg text-center mb-8"
            style={{ color: "var(--accent-light)" }}
          >
            Talk to the version of yourself who already lived the next 10 years.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="space-y-4 mb-10"
            style={{ color: "var(--text-secondary)" }}
          >
            <p className="text-center leading-relaxed">
              Most AI assistants only know what is said in the current conversation.
            </p>
            <p className="text-center leading-relaxed">
              Future You AI imports context from previous AI conversations and creates a
              realistic simulation of a future version of the user.
            </p>
            <p className="text-center leading-relaxed">
              The more context provided, the more accurate and personalized the future
              simulation becomes.
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center"
          >
            <button
              onClick={handleStartFresh}
              className="btn-accent flex items-center justify-center gap-2 text-base py-4 px-8"
            >
              <FileText className="w-5 h-5" />
              Generate Import Prompt
            </button>
            <button
              onClick={handleContinue}
              className="btn-secondary flex items-center justify-center gap-2 text-base py-4 px-8"
            >
              Continue
              <ArrowRight className="w-5 h-5" />
            </button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
}
