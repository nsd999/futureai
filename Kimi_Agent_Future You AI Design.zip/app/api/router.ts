import { authRouter } from "./auth-router";
import { profileRouter } from "./profile-router";
import { simulationRouter } from "./simulation-router";
import { futuresRouter } from "./futures-router";
import { chatRouter } from "./chat-router";
import { contentRouter } from "./content-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  profile: profileRouter,
  simulation: simulationRouter,
  futures: futuresRouter,
  chat: chatRouter,
  content: contentRouter,
});

export type AppRouter = typeof appRouter;
