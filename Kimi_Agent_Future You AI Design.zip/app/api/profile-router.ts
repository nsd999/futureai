import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";

export const profileRouter = createRouter({
  get: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const rows = await db
      .select()
      .from(schema.profiles)
      .where(eq(schema.profiles.userId, ctx.user.id))
      .orderBy(desc(schema.profiles.createdAt))
      .limit(1);
    return rows.at(0) ?? null;
  }),

  create: authedQuery
    .input(
      z.object({
        rawText: z.string().optional(),
        parsedData: z.any().optional(),
        personalDetails: z.any().optional(),
        goals: z.array(z.string()).optional(),
        habits: z.any().optional(),
        personality: z.any().optional(),
        preferences: z.any().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const values: Record<string, unknown> = {
        userId: ctx.user.id,
      };
      if (input.rawText !== undefined) values.rawText = input.rawText;
      if (input.parsedData !== undefined) values.parsedData = input.parsedData;
      if (input.personalDetails !== undefined) values.personalDetails = input.personalDetails;
      if (input.goals !== undefined) values.goals = input.goals;
      if (input.habits !== undefined) values.habits = input.habits;
      if (input.personality !== undefined) values.personality = input.personality;
      if (input.preferences !== undefined) values.preferences = input.preferences;
      const result = await db.insert(schema.profiles).values(values as schema.InsertProfile);
      return { id: Number(result[0].insertId) };
    }),

  update: authedQuery
    .input(
      z.object({
        id: z.number(),
        rawText: z.string().optional(),
        parsedData: z.any().optional(),
        personalDetails: z.any().optional(),
        goals: z.array(z.string()).optional(),
        habits: z.any().optional(),
        personality: z.any().optional(),
        preferences: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const { id, ...data } = input;
      const setValues: Record<string, unknown> = {};
      if (data.rawText !== undefined) setValues.rawText = data.rawText;
      if (data.parsedData !== undefined) setValues.parsedData = data.parsedData;
      if (data.personalDetails !== undefined) setValues.personalDetails = data.personalDetails;
      if (data.goals !== undefined) setValues.goals = data.goals;
      if (data.habits !== undefined) setValues.habits = data.habits;
      if (data.personality !== undefined) setValues.personality = data.personality;
      if (data.preferences !== undefined) setValues.preferences = data.preferences;
      await db
        .update(schema.profiles)
        .set(setValues)
        .where(eq(schema.profiles.id, id));
      return { success: true };
    }),
});
