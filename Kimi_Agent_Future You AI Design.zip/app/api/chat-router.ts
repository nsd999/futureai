import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";
import { generateFutureSelfResponse } from "./lib/ai";

export const chatRouter = createRouter({
  history: authedQuery
    .input(
      z.object({
        limit: z.number().optional().default(50),
        offset: z.number().optional().default(0),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      return db
        .select()
        .from(schema.chatMessages)
        .where(eq(schema.chatMessages.userId, ctx.user.id))
        .orderBy(desc(schema.chatMessages.createdAt))
        .limit(input.limit)
        .offset(input.offset);
    }),

  send: authedQuery
    .input(
      z.object({
        content: z.string().min(1),
        runId: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      await db.insert(schema.chatMessages).values({
        userId: ctx.user.id,
        simulationRunId: input.runId,
        role: "user",
        content: input.content,
      });

      let context: Record<string, unknown> = {};

      if (input.runId) {
        const futuresData = await db
          .select()
          .from(schema.futures)
          .where(eq(schema.futures.simulationRunId, input.runId));

        const profileRows = await db
          .select()
          .from(schema.profiles)
          .where(eq(schema.profiles.userId, ctx.user.id))
          .orderBy(desc(schema.profiles.createdAt))
          .limit(1);
        const profile = profileRows.at(0);

        const recentMessages = await db
          .select()
          .from(schema.chatMessages)
          .where(eq(schema.chatMessages.userId, ctx.user.id))
          .orderBy(desc(schema.chatMessages.createdAt))
          .limit(20);

        context = {
          futures: futuresData,
          profile: profile
            ? {
                personalDetails: profile.personalDetails,
                goals: profile.goals,
                personality: profile.personality,
              }
            : undefined,
          recentMessages: recentMessages.reverse(),
        };
      }

      const response = await generateFutureSelfResponse(
        input.content,
        ctx.user.name ?? "User",
        context
      );

      await db.insert(schema.chatMessages).values({
        userId: ctx.user.id,
        simulationRunId: input.runId,
        role: "assistant",
        content: response,
        context: { generated: true },
      });

      return { response };
    }),

  clearHistory: authedQuery.mutation(async ({ ctx }) => {
    const db = getDb();
    await db
      .delete(schema.chatMessages)
      .where(eq(schema.chatMessages.userId, ctx.user.id));
    return { success: true };
  }),
});
