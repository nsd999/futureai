import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";

export const contentRouter = createRouter({
  list: authedQuery
    .input(
      z.object({
        runId: z.number(),
        contentType: z.string().optional(),
      })
    )
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const runRows = await db
        .select()
        .from(schema.simulationRuns)
        .where(eq(schema.simulationRuns.id, input.runId))
        .limit(1);
      const run = runRows.at(0);
      if (!run || run.userId !== ctx.user.id) return [];

      if (input.contentType) {
        return db
          .select()
          .from(schema.generatedContent)
          .where(
            and(
              eq(schema.generatedContent.simulationRunId, input.runId),
              eq(
                schema.generatedContent.contentType,
                input.contentType as "letter" | "news_article" | "linkedin_profile" | "regret_analysis" | "wake_up_call" | "funeral_speech" | "legacy_score"
              )
            )
          );
      }

      return db
        .select()
        .from(schema.generatedContent)
        .where(eq(schema.generatedContent.simulationRunId, input.runId));
    }),

  create: authedQuery
    .input(
      z.object({
        simulationRunId: z.number(),
        contentType: z.enum([
          "letter",
          "news_article",
          "linkedin_profile",
          "regret_analysis",
          "wake_up_call",
          "funeral_speech",
          "legacy_score",
        ]),
        title: z.string().optional(),
        content: z.string(),
        metadata: z.any().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(schema.generatedContent).values({
        simulationRunId: input.simulationRunId,
        contentType: input.contentType,
        title: input.title ?? null,
        content: input.content,
        metadata: input.metadata ?? null,
      });
      return { id: Number(result[0].insertId) };
    }),

  get: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.generatedContent)
        .where(eq(schema.generatedContent.id, input.id))
        .limit(1);
      const content = rows.at(0);
      if (!content) return null;

      const runRows = await db
        .select()
        .from(schema.simulationRuns)
        .where(eq(schema.simulationRuns.id, content.simulationRunId))
        .limit(1);
      const run = runRows.at(0);
      if (!run || run.userId !== ctx.user.id) return null;

      return content;
    }),
});
