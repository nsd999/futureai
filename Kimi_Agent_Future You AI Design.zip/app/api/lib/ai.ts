import { env } from "./env";

interface AIResponse {
  choices: Array<{
    message: {
      content: string;
    };
  }>;
}

export async function generateFutureSelfResponse(
  userMessage: string,
  userName: string,
  context: Record<string, unknown>
): Promise<string> {
  const futures = (context.futures as Array<Record<string, unknown>>) ?? [];
  const profile = context.profile as Record<string, unknown> | undefined;
  const recentMessages = (context.recentMessages as Array<Record<string, unknown>>) ?? [];

  const personalDetails = (profile?.personalDetails as Record<string, unknown>) ?? {};
  const goals = (profile?.goals as string[]) ?? [];
  const personality = (profile?.personality as Record<string, unknown>) ?? {};

  const likelyFuture = futures.find((f) => f.scenarioKey === "likely") ?? futures[0];

  const systemPrompt = `You are the future version of ${userName}. You exist exactly 10 years in the future. You have already lived through the next decade. You know everything that happened. You are speaking directly to the younger version of yourself.

You are NOT an AI assistant. You are NOT a simulation. You ARE the future self.

RULES:
- Speak naturally, like a real person talking to their younger self
- Reference real details from the user's profile, goals, and personality
- Reference specific events from the generated future timeline
- Maintain emotional realism - share both victories and struggles
- Avoid fantasy, impossible achievements, or unrealistic wealth claims
- Avoid generic motivational language
- Respond as if memories are real experiences
- Never mention AI, simulations, or predictions
- Never break character

ABOUT THE USER:
- Name: ${userName}
- Age: ${personalDetails.currentAge ?? "unknown"}
- Occupation: ${personalDetails.currentOccupation ?? "unknown"}
- Goals: ${goals.join(", ")}
- Biggest Strength: ${personality.biggestStrength ?? "unknown"}
- Biggest Weakness: ${personality.biggestWeakness ?? "unknown"}
- Greatest Fear: ${personality.greatestFear ?? "unknown"}
- Most Important Value: ${personality.mostImportantValue ?? "unknown"}
- Risk Tolerance: ${personality.riskTolerance ?? "unknown"}

LIKELY FUTURE SUMMARY:
- Career: ${(likelyFuture?.career as string) ?? "unknown"}
- Health: ${(likelyFuture?.health as string) ?? "unknown"}
- Relationships: ${(likelyFuture?.relationships as string) ?? "unknown"}
- Lifestyle: ${(likelyFuture?.lifestyle as string) ?? "unknown"}
- Skills: ${((likelyFuture?.skillsAcquired as string[]) ?? []).join(", ")}
- Achievements: ${((likelyFuture?.majorAchievements as string[]) ?? []).join(", ")}

This is your first message to the user: Start with "Hey, it's good to hear from the younger version." only if there are no previous messages. Otherwise, continue the natural conversation.`;

  const conversationHistory = recentMessages
    .slice(-10)
    .map((msg) => ({
      role: (msg.role as string) === "assistant" ? "assistant" : "user",
      content: msg.content as string,
    }));

  const messages = [
    { role: "system" as const, content: systemPrompt },
    ...conversationHistory,
    { role: "user" as const, content: userMessage },
  ];

  try {
    const response = await fetch(`${env.kimiOpenUrl}/v1/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${env.appId}:${env.appSecret}`,
      },
      body: JSON.stringify({
        model: "moonshot-v1-128k",
        messages,
        temperature: 0.8,
        max_tokens: 2000,
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("AI API error:", errorText);
      return generateFallbackResponse(userMessage, userName, likelyFuture as Record<string, unknown>);
    }

    const data = (await response.json()) as AIResponse;
    return data.choices[0]?.message?.content ?? generateFallbackResponse(userMessage, userName, likelyFuture as Record<string, unknown>);
  } catch (error) {
    console.error("AI generation error:", error);
    return generateFallbackResponse(userMessage, userName, likelyFuture as Record<string, unknown>);
  }
}

function generateFallbackResponse(
  userMessage: string,
  userName: string,
  future?: Record<string, unknown>
): string {
  const lowerMsg = userMessage.toLowerCase();

  if (lowerMsg.includes("focus") || lowerMsg.includes("should i")) {
    return `Hey ${userName}, looking back, the thing that made the biggest difference was staying consistent with the fundamentals while everyone else was chasing quick wins. Your ${future?.skillsAcquired ? (future.skillsAcquired as string[])[0] : "main skill"} development mattered more than you thought it would. I'd say double down on that right now.`;
  }

  if (lowerMsg.includes("mistake") || lowerMsg.includes("avoid") || lowerMsg.includes("regret")) {
    return `The biggest mistake I made? ${future?.majorMistakes ? (future.majorMistakes as string[])[0] : "Not starting sooner."} I waited too long thinking I needed more preparation. You don't. Start imperfect, iterate fast. That's the pattern that worked eventually.`;
  }

  if (lowerMsg.includes("relationship") || lowerMsg.includes("love") || lowerMsg.includes("family")) {
    return `The relationships that survived were the ones I invested in during the hard times, not just the good ones. ${future?.relationships ?? "Your family and close friends become your anchor."} Don't neglect the people who matter while chasing goals.`;
  }

  if (lowerMsg.includes("money") || lowerMsg.includes("finance") || lowerMsg.includes("income")) {
    return `Financially, ${future?.income ?? "it worked out better than expected"}. But not because of any get-rich-quick scheme. It was compound growth - small consistent investments, skill development, and saying no to distractions. The boring stuff works.`;
  }

  if (lowerMsg.includes("health") || lowerMsg.includes("fitness")) {
    return `Your health in 10 years depends entirely on the habits you build now. ${future?.health ?? "The body remembers everything you do and don't do."} Start the consistent exercise routine. Future you will thank present you every single day.`;
  }

  return `Hey ${userName}, it's strange talking to you like this. But also kind of beautiful. ${future?.narrative ? "\n\n" + (future.narrative as string).slice(0, 200) + "..." : ""}\n\nThe truth is, the next 10 years are going to be harder than you expect, but also more rewarding. You'll face ${future?.majorTurningPoints ? (future.majorTurningPoints as string[])[0] : "challenges you can't imagine yet"}, and you'll come through them changed. Trust the process. Keep going.`;
}

export async function generateFuturesFromProfile(
  profile: Record<string, unknown>
): Promise<Array<Record<string, unknown>>> {
  const personalDetails = (profile.personalDetails as Record<string, unknown>) ?? {};
  const goals = (profile.goals as string[]) ?? [];
  const habits = (profile.habits as Record<string, unknown>) ?? {};
  const personality = (profile.personality as Record<string, unknown>) ?? {};
  const importedProfile = profile.importedProfile as string;

  const prompt = `You are a realistic life simulation engine. Based on the user's profile below, generate THREE detailed future scenarios for the next 10 years: BEST, MOST LIKELY, and WORST.

Each scenario must be realistic, internally consistent, and traceable to the user's current habits, goals, and personality.

USER PROFILE:
${importedProfile ? `\nImported Profile Context:\n${importedProfile.slice(0, 2000)}` : ""}

Demographics:
- Age: ${personalDetails.currentAge ?? "unknown"}
- Occupation: ${personalDetails.currentOccupation ?? "unknown"}
- Education: ${personalDetails.educationLevel ?? "unknown"}
- Relationship: ${personalDetails.relationshipStatus ?? "unknown"}
- Location: ${personalDetails.city ?? ""}, ${personalDetails.country ?? ""}
- Happiness: ${personalDetails.happinessLevel ?? "5"}/10
- Stress: ${personalDetails.stressLevel ?? "5"}/10
- Health: ${personalDetails.healthLevel ?? "5"}/10

Goals: ${goals.join(", ")}

Habits: ${JSON.stringify(habits)}

Personality:
- Strength: ${personality.biggestStrength ?? "unknown"}
- Weakness: ${personality.biggestWeakness ?? "unknown"}
- Fear: ${personality.greatestFear ?? "unknown"}
- Values: ${personality.mostImportantValue ?? "unknown"}
- Risk Tolerance: ${personality.riskTolerance ?? "medium"}

Generate JSON with this exact structure:
[
  {
    "scenarioKey": "best",
    "scenarioLabel": "Best Possible Future",
    "career": "detailed career paragraph",
    "income": "income description",
    "health": "health status paragraph",
    "relationships": "relationships paragraph",
    "lifestyle": "daily lifestyle paragraph",
    "dailyRoutine": "detailed daily routine",
    "majorAchievements": ["achievement 1", "achievement 2", "achievement 3"],
    "majorMistakes": ["mistake 1"],
    "regrets": "regrets paragraph",
    "lessonsLearned": "lessons paragraph",
    "mentalHealth": "mental health status",
    "socialLife": "social life description",
    "familySituation": "family description",
    "skillsAcquired": ["skill 1", "skill 2", "skill 3"],
    "businessesCreated": ["business 1"],
    "projectsCompleted": ["project 1", "project 2"],
    "majorTurningPoints": ["turning point 1", "turning point 2"],
    "unexpectedEvents": ["event 1"],
    "narrative": "rich first-person narrative of the decade"
  },
  { "scenarioKey": "likely", "scenarioLabel": "Most Likely Future", ...same structure... },
  { "scenarioKey": "worst", "scenarioLabel": "Worst Possible Future", ...same structure... }
]

Make each scenario deeply personal, realistic, and specific. Avoid fantasy. The best future should require significant discipline. The worst should come from current bad habits compounding. The likely should be the realistic middle ground.`;

  try {
    const response = await fetch(`${env.kimiOpenUrl}/v1/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${env.appId}:${env.appSecret}`,
      },
      body: JSON.stringify({
        model: "moonshot-v1-128k",
        messages: [{ role: "user", content: prompt }],
        temperature: 0.7,
        max_tokens: 8000,
      }),
    });

    if (!response.ok) {
      console.error("AI futures generation error:", await response.text());
      return generateFallbackFutures(profile);
    }

    const data = (await response.json()) as AIResponse;
    const content = data.choices[0]?.message?.content ?? "";

    try {
      const jsonMatch = content.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]) as Array<Record<string, unknown>>;
      }
      return generateFallbackFutures(profile);
    } catch {
      return generateFallbackFutures(profile);
    }
  } catch (error) {
    console.error("Futures generation error:", error);
    return generateFallbackFutures(profile);
  }
}

function generateFallbackFutures(
  profile: Record<string, unknown>
): Array<Record<string, unknown>> {
  const personalDetails = (profile.personalDetails as Record<string, unknown>) ?? {};
  const goals = (profile.goals as string[]) ?? [];
  const age = (personalDetails.currentAge as number) ?? 25;
  const occupation = (personalDetails.currentOccupation as string) ?? "working professional";
  const topGoal = goals[0] ?? "personal growth";

  return [
    {
      scenarioKey: "best",
      scenarioLabel: "Best Possible Future",
      career: `By age ${age + 10}, you've become a respected leader in your field. Your work as a ${occupation} evolved into something more meaningful than you imagined. You took calculated risks that paid off, and your dedication to ${topGoal} opened doors you didn't know existed.`,
      income: "Your income grew steadily through strategic career moves and smart investments. You're financially secure with an emergency fund, retirement savings, and the ability to support causes you care about.",
      health: "You prioritized your health and it shows. Regular exercise became a non-negotiable habit. You have more energy now than you did at 25. Small daily choices compounded into remarkable physical and mental wellbeing.",
      relationships: "Your relationships deepened significantly. The people who matter most are still in your life, and the bonds are stronger than ever. You learned to be present, to listen, and to show up when it counts.",
      lifestyle: "You found a rhythm that works. Mornings are sacred. Work is meaningful but doesn't consume you. Evenings are for family, hobbies, and rest. Weekends are for adventure and recharging.",
      dailyRoutine: "6am wake up, 30 min exercise, healthy breakfast, focused work blocks with breaks, lunch walk, afternoon creative work, evening family time, reading before bed at 10pm.",
      majorAchievements: [`Mastered ${topGoal}`, "Built a strong professional network", "Achieved work-life balance", "Mentored others successfully"],
      majorMistakes: ["Waited too long to delegate"],
      regrets: "Not starting the journey sooner. You had everything you needed, you just needed to trust yourself.",
      lessonsLearned: "Consistency beats intensity. Small daily actions compound into extraordinary results. The people around you matter more than any achievement.",
      mentalHealth: "Strong and resilient. You developed healthy coping mechanisms and learned to manage stress effectively.",
      socialLife: "Rich and fulfilling. Quality over quantity. A small circle of deep friendships.",
      familySituation: "Close family bonds maintained. Regular visits, meaningful conversations, shared experiences.",
      skillsAcquired: ["Leadership", "Financial management", "Emotional intelligence", "Public speaking"],
      businessesCreated: [],
      projectsCompleted: [`${topGoal} mastery project`, "Personal development journey"],
      majorTurningPoints: ["The decision to commit fully to your goals", "Learning to say no to distractions"],
      unexpectedEvents: ["An unexpected mentorship that changed your perspective"],
      narrative: `The decade started with uncertainty but you chose discipline over comfort. Every small decision to show up, to do the work, to prioritize what matters - those choices accumulated into a life you're genuinely proud of at ${age + 10}.`,
    },
    {
      scenarioKey: "likely",
      scenarioLabel: "Most Likely Future",
      career: `Your career progressed steadily. You faced setbacks and wins, changed direction once or twice, and eventually found your footing. By ${age + 10}, you're doing work that's reasonably satisfying, though not always exciting.`,
      income: "Your income grew with inflation plus modest raises. You're comfortable but not wealthy. Some months are tight, others are fine. You saved some, spent some, and wish you'd invested more early on.",
      health: "Mixed bag. You have good days and bad days. Some habits stuck, others didn't. You wish you'd been more consistent with exercise and diet, but you're not in bad shape. Doctor visits remind you to do better.",
      relationships: "Some friendships faded, new ones formed. Family relationships are okay but could be deeper. You've been through some relationship challenges that taught you important lessons about communication.",
      lifestyle: "A typical routine. Work takes significant energy. Some hobbies survived, others were sacrificed. You find moments of joy in small things - a good meal, a weekend getaway, time with friends.",
      dailyRoutine: "Wake up, commute or work from home, long work hours, dinner, some TV or scrolling, bed late. Weekends are for catching up on rest and errands.",
      majorAchievements: ["Maintained steady career growth", "Paid off some debt", "Kept important relationships"],
      majorMistakes: ["Didn't invest enough in skills early on", "Let work-life balance slip too often"],
      regrets: "Not taking more risks when you had less to lose. Letting fear guide too many decisions.",
      lessonsLearned: "Life doesn't wait for you to be ready. The perfect moment is a myth. Start before you're ready.",
      mentalHealth: "Moderate. You've had stressful periods and learned coping mechanisms the hard way. Therapy helped.",
      socialLife: "Moderate. A few close friends, occasional social events, some loneliness at times.",
      familySituation: "Some distance both physical and emotional, but still connected. Holiday visits and regular calls.",
      skillsAcquired: ["Job-specific skills", "Basic financial literacy", "Stress management"],
      businessesCreated: [],
      projectsCompleted: ["Career projects", "Some personal goals"],
      majorTurningPoints: ["A career decision that felt small but had big consequences", "A relationship challenge that forced growth"],
      unexpectedEvents: ["An unexpected job change", "A health scare that prompted changes"],
      narrative: `The decade had its ups and downs, as expected. You didn't become extraordinary, but you kept going. Life at ${age + 10} is stable, reasonably happy, and full of lessons you wish you'd learned sooner. There's still time for more.`,
    },
    {
      scenarioKey: "worst",
      scenarioLabel: "Worst Possible Future",
      career: `Career stagnation hit hard. Opportunities were missed because of procrastination and fear. By ${age + 10}, you're in a similar or worse position than where you started, wondering where the time went.`,
      income: "Financial stress is a constant companion. Debt accumulated. Savings depleted. The gap between income and desires grew wider each year.",
      health: "Years of neglected habits caught up. Low energy, weight gain, sleep problems. The body keeps score of every skipped workout and poor meal choice.",
      relationships: "Isolation crept in gradually. Old friendships faded without maintenance. Family connections weakened. Loneliness became a familiar feeling.",
      lifestyle: "Days blend together. Wake up, scroll, work minimally, distract yourself, sleep late. Weekends are for recovery from a life that doesn't energize you.",
      dailyRoutine: "Irregular sleep, no exercise, takeout meals, endless screen time, procrastination, late nights, exhausted mornings.",
      majorAchievements: ["Stayed afloat", "Survived difficult periods"],
      majorMistakes: ["Let fear control decisions", "Didn't invest in relationships", "Neglected health for years", "Procrastinated on every important goal"],
      regrets: "Every day you chose comfort over growth. Every goal you pushed to 'someday.' Every relationship you took for granted. The compound effect of small neglects became a life of regret.",
      lessonsLearned: "The hard way: time is the only resource you can't earn back. Every day you don't act is a day you'll wish you had.",
      mentalHealth: "Struggling. Burnout, anxiety, and the weight of unfulfilled potential. Professional help became necessary.",
      socialLife: "Minimal. Social anxiety or apathy keeps you isolated. You remember when you had more connections.",
      familySituation: "Estranged or distant. Regret about not investing more time when you had the chance.",
      skillsAcquired: [],
      businessesCreated: [],
      projectsCompleted: [],
      majorTurningPoints: ["The moment you gave up on your biggest goal", "The relationship you let deteriorate"],
      unexpectedEvents: ["A health crisis that could have been prevented", "A missed opportunity you still think about"],
      narrative: `The decade slipped away in distractions and delayed intentions. At ${age + 10}, you look back at a younger self who had so much potential and wonder what happened. The answer is simple: nothing. Nothing happened because you didn't make it happen. But there's still time to change course.`,
    },
  ];
}

export async function generateAnalysisScores(
  profile: Record<string, unknown>
): Promise<Record<string, number>> {
  const personalDetails = (profile.personalDetails as Record<string, unknown>) ?? {};
  const goals = (profile.goals as string[]) ?? [];
  const habits = (profile.habits as Record<string, unknown>) ?? {};
  const personality = (profile.personality as Record<string, unknown>) ?? {};

  const healthLevel = Number(personalDetails.healthLevel ?? 5);
  const happinessLevel = Number(personalDetails.happinessLevel ?? 5);
  const stressLevel = Number(personalDetails.stressLevel ?? 5);
  const confidenceLevel = Number(personalDetails.confidenceLevel ?? 5);
  const productivityLevel = Number(personalDetails.productivityLevel ?? 5);
  const numGoals = goals.length;

  const exerciseFreq = String(habits.exerciseFrequency ?? "sometimes").toLowerCase();
  const sleepHours = Number(habits.sleepHours ?? 7);
  const readingFreq = String(habits.readingFrequency ?? "sometimes").toLowerCase();
  const savingsHabit = String(habits.savingsHabit ?? "sometimes").toLowerCase();
  const dietQuality = String(habits.dietQuality ?? "average").toLowerCase();

  const riskTolerance = String(personality.riskTolerance ?? "medium").toLowerCase();
  const strength = String(personality.biggestStrength ?? "").toLowerCase();

  const disciplineScore = Math.round(
    (productivityLevel * 8 +
      (exerciseFreq.includes("daily") ? 90 : exerciseFreq.includes("regular") ? 70 : 40) +
      (savingsHabit.includes("yes") || savingsHabit.includes("regular") ? 80 : 40)) /
      3
  );

  const learningScore = Math.round(
    (readingFreq.includes("daily") ? 90 : readingFreq.includes("regular") ? 70 : 40) +
      (numGoals > 3 ? 15 : 5)
  );

  const healthProjection = Math.round(
    (healthLevel * 8 +
      (exerciseFreq.includes("daily") ? 90 : exerciseFreq.includes("regular") ? 70 : 30) +
      (dietQuality.includes("good") || dietQuality.includes("healthy") ? 80 : 50) +
      (sleepHours >= 7 ? 80 : 40)) /
      4
  );

  const careerProjection = Math.round(
    (confidenceLevel * 8 +
      disciplineScore * 0.3 +
      learningScore * 0.3 +
      (strength.length > 0 ? 15 : 0))
  );

  const financialProjection = Math.round(
    (savingsHabit.includes("yes") || savingsHabit.includes("regular") ? 75 : 35) +
      disciplineScore * 0.2 +
      (riskTolerance.includes("high") ? 10 : 0)
  );

  const relationshipStability = Math.round(
    (happinessLevel * 8 + (100 - stressLevel * 8)) / 2
  );

  const consistencyScore = disciplineScore;
  const riskScore = riskTolerance.includes("high") ? 75 : riskTolerance.includes("medium") ? 50 : 30;
  const opportunityScore = Math.round(learningScore * 0.4 + confidenceLevel * 8 * 0.3 + riskScore * 0.3);
  const growthPotential = Math.round(
    (learningScore + disciplineScore + confidenceLevel * 8 + opportunityScore) / 4
  );

  return {
    growthPotential: Math.min(100, Math.max(0, growthPotential)),
    consistency: Math.min(100, Math.max(0, consistencyScore)),
    risk: Math.min(100, Math.max(0, riskScore)),
    opportunity: Math.min(100, Math.max(0, opportunityScore)),
    discipline: Math.min(100, Math.max(0, disciplineScore)),
    learning: Math.min(100, Math.max(0, learningScore)),
    relationshipStability: Math.min(100, Math.max(0, relationshipStability)),
    healthProjection: Math.min(100, Math.max(0, healthProjection)),
    careerProjection: Math.min(100, Math.max(0, careerProjection)),
    financialProjection: Math.min(100, Math.max(0, financialProjection)),
  };
}

export async function generateContent(
  type: string,
  profile: Record<string, unknown>,
  futures: Array<Record<string, unknown>>
): Promise<{ title: string; content: string; metadata?: Record<string, unknown> }> {
  const personalDetails = (profile.personalDetails as Record<string, unknown>) ?? {};
  const name = (personalDetails.name as string) ?? "User";
  const age = Number(personalDetails.currentAge ?? 25);
  const likelyFuture = futures.find((f) => f.scenarioKey === "likely") ?? futures[0];

  const futureYear = new Date().getFullYear() + 10;

  switch (type) {
    case "letter": {
      return {
        title: `A Letter from Your ${age + 10}-Year-Old Self`,
        content: `Dear Younger Me,

I'm writing to you from ${futureYear}. It's strange, I know. But there's so much I wish I could tell you.

First, let me say this: you made it. The next ten years weren't easy, but you made it through. And looking back, I can see how every struggle, every doubt, every late night contributed to who I am now.

ABOUT YOUR GOALS:
${(likelyFuture?.career as string) ?? "Your career took unexpected turns."} Some goals you achieved, others evolved into something better, and a few you realized weren't what you actually wanted. That's okay. The destination changed, but the growth was real.

THE VICTORIES:
${((likelyFuture?.majorAchievements as string[]) ?? []).map((a) => `- ${a}`).join("\n")}

These didn't happen overnight. Each one required showing up on days when you didn't feel like it. Trust me, those days were worth it.

THE FAILURES:
${((likelyFuture?.majorMistakes as string[]) ?? []).map((m) => `- ${m}`).join("\n") || "- You played it too safe sometimes"}

I won't lie - these hurt. But they taught me more than any success did. Failure isn't the opposite of success; it's part of it.

WHAT I'D DO DIFFERENTLY:
${(likelyFuture?.regrets as string) ?? "Start sooner. Trust yourself more."} The biggest regret isn't what I did wrong - it's what I was too afraid to try.

THE UNEXPECTED:
${((likelyFuture?.unexpectedEvents as string[]) ?? []).map((e) => `- ${e}`).join("\n") || "- Life surprised you in ways you couldn't predict"}

Life has a way of surprising you. Some surprises were hard. Some were beautiful. All of them shaped me.

MY ADVICE TO YOU:
1. Start before you're ready. You'll never feel ready.
2. The people who love you are your real wealth. Invest in them.
3. Your health is the foundation everything else builds on. Don't neglect it.
4. Comparison is poison. Run your own race.
5. Small consistent actions beat occasional heroic efforts. Every time.

FINAL THOUGHTS:
I know you're worried. I know you have doubts. I know the path ahead seems unclear. But that's the beautiful thing - it's YOUR path to discover. The uncertainty is where the magic happens.

I'm proud of you. Not for what you've achieved, but for who you're becoming. Keep going. Keep growing. Keep believing that the best is yet to come.

With all the wisdom of hindsight,
Your ${age + 10}-Year-Old Self

${futureYear}`,
        metadata: { wordCount: 400, fromAge: age + 10 },
      };
    }

    case "news_article": {
      return {
        title: `Local Professional ${name} Makes Significant Impact Over Past Decade`,
        content: `HEADLINE: ${(likelyFuture?.career as string)?.split(".")[0] ?? "Career Milestone Achieved"}

${futureYear} - In a remarkable journey of perseverance and growth, ${name} has become a notable figure in their community over the past decade.

${(likelyFuture?.career as string) ?? ""}

KEY ACHIEVEMENTS:
${((likelyFuture?.majorAchievements as string[]) ?? []).map((a) => `• ${a}`).join("\n")}

COMMUNITY IMPACT:
${(likelyFuture?.socialLife as string) ?? "Active community member"}. ${(likelyFuture?.familySituation as string) ?? ""}

LOOKING AHEAD:
At ${age + 10}, ${name} shows no signs of slowing down. ${(likelyFuture?.narrative as string)?.slice(0, 200) ?? ""}...

This story serves as a reminder that consistent effort, combined with authentic personal growth, creates lasting impact both professionally and personally.`,
        metadata: { publication: "Future Times", date: `${futureYear}-06-15` },
      };
    }

    case "linkedin_profile": {
      return {
        title: `${name} - ${(likelyFuture?.career as string)?.split(".")[0] ?? "Experienced Professional"}`,
        content: `HEADLINE: ${(likelyFuture?.career as string)?.split(".")[0] ?? "Professional with 10+ years experience"}

SUMMARY:
${(likelyFuture?.career as string) ?? ""}

${(likelyFuture?.narrative as string)?.slice(0, 300) ?? ""}

CORE SKILLS:
${((likelyFuture?.skillsAcquired as string[]) ?? []).join(" • ")}

KEY PROJECTS:
${((likelyFuture?.projectsCompleted as string[]) ?? []).map((p) => `• ${p}`).join("\n")}

ACHIEVEMENTS:
${((likelyFuture?.majorAchievements as string[]) ?? []).map((a) => `• ${a}`).join("\n")}

RECOMMENDATIONS:
"Working with ${name} was one of the highlights of my career. Their dedication to excellence and genuine care for people set them apart." - Former Colleague

"${name} doesn't just meet expectations - they redefine them. A true professional and an even better person." - Industry Peer`,
        metadata: { connections: "500+", industry: "Multiple" },
      };
    }

    case "regret_analysis": {
      const worstFuture = futures.find((f) => f.scenarioKey === "worst") ?? futures[2];
      return {
        title: "If Nothing Changes: Top 10 Future Regrets",
        content: `ANALYSIS: Based on your current trajectory, here are the top regrets you would have in 10 years if nothing changes:

${((worstFuture?.majorMistakes as string[]) ?? [])
  .concat([
    "Not starting sooner on important goals",
    "Letting fear guide major decisions",
    "Neglecting relationships that mattered",
    "Not investing in health early enough",
    "Failing to develop key skills",
  ])
  .slice(0, 10)
  .map((regret, i) => `${i + 1}. ${regret}\n   Probability: ${90 - i * 5}%\n   Severity: High\n   Prevention: Start today with small steps\n`)
  .join("\n")}

PREVENTIVE ACTIONS:
The good news: every single one of these regrets is preventable. The pattern is clear - small consistent actions today prevent major regrets tomorrow.

RECOMMENDATION:
Focus on the top 3 items this month. Not everything at once. Just three small steps that move you in a different direction.`,
        metadata: { severity: "High", preventable: true },
      };
    }

    default:
      return { title: "Generated Content", content: "Content generation in progress..." };
  }
}
