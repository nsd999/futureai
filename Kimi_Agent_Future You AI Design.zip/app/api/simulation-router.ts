import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";

export const simulationRouter = createRouter({
  list: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    return db
      .select()
      .from(schema.simulationRuns)
      .where(eq(schema.simulationRuns.userId, ctx.user.id))
      .orderBy(desc(schema.simulationRuns.createdAt));
  }),

  get: authedQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const runs = await db
        .select()
        .from(schema.simulationRuns)
        .where(eq(schema.simulationRuns.id, input.id))
        .limit(1);
      const run = runs.at(0);
      if (!run || run.userId !== ctx.user.id) return null;

      const futuresData = await db
        .select()
        .from(schema.futures)
        .where(eq(schema.futures.simulationRunId, input.id));

      const scores = await db
        .select()
        .from(schema.analysisScores)
        .where(eq(schema.analysisScores.simulationRunId, input.id))
        .limit(1);

      const content = await db
        .select()
        .from(schema.generatedContent)
        .where(eq(schema.generatedContent.simulationRunId, input.id));

      return { ...run, futures: futuresData, scores: scores.at(0) ?? null, content };
    }),

  start: authedQuery
    .input(z.object({ profileId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const result = await db.insert(schema.simulationRuns).values({
        userId: ctx.user.id,
        profileId: input.profileId,
        status: "pending",
        progressStep: 0,
        progressMessage: "Initializing simulation...",
      });
      return { runId: Number(result[0].insertId) };
    }),

  status: authedQuery
    .input(z.object({ runId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const rows = await db
        .select()
        .from(schema.simulationRuns)
        .where(eq(schema.simulationRuns.id, input.runId))
        .limit(1);
      const run = rows.at(0);
      if (!run || run.userId !== ctx.user.id) return null;
      return {
        status: run.status,
        progressStep: run.progressStep,
        progressMessage: run.progressMessage,
      };
    }),

  updateProgress: authedQuery
    .input(
      z.object({
        runId: z.number(),
        step: z.number(),
        message: z.string(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(schema.simulationRuns)
        .set({
          progressStep: input.step,
          progressMessage: input.message,
          status: input.step >= 5 ? "completed" : "generating",
          generatedAt: input.step >= 5 ? new Date() : undefined,
        })
        .where(eq(schema.simulationRuns.id, input.runId));
      return { success: true };
    }),

  complete: authedQuery
    .input(z.object({ runId: z.number() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      await db
        .update(schema.simulationRuns)
        .set({
          status: "completed",
          progressStep: 5,
          progressMessage: "Simulation complete!",
          generatedAt: new Date(),
        })
        .where(eq(schema.simulationRuns.id, input.runId));
      return { success: true };
    }),
});
