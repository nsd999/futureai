import { z } from "zod";
import { eq } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import * as schema from "@db/schema";

export const futuresRouter = createRouter({
  list: authedQuery
    .input(z.object({ runId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const runRows = await db
        .select()
        .from(schema.simulationRuns)
        .where(eq(schema.simulationRuns.id, input.runId))
        .limit(1);
      const run = runRows.at(0);
      if (!run || run.userId !== ctx.user.id) return [];

      return db
        .select()
        .from(schema.futures)
        .where(eq(schema.futures.simulationRunId, input.runId));
    }),

  create: authedQuery
    .input(
      z.object({
        simulationRunId: z.number(),
        scenarioKey: z.string(),
        scenarioLabel: z.string(),
        career: z.string().optional(),
        income: z.string().optional(),
        health: z.string().optional(),
        relationships: z.string().optional(),
        lifestyle: z.string().optional(),
        dailyRoutine: z.string().optional(),
        majorAchievements: z.array(z.string()).optional(),
        majorMistakes: z.array(z.string()).optional(),
        regrets: z.string().optional(),
        lessonsLearned: z.string().optional(),
        mentalHealth: z.string().optional(),
        socialLife: z.string().optional(),
        familySituation: z.string().optional(),
        skillsAcquired: z.array(z.string()).optional(),
        businessesCreated: z.array(z.string()).optional(),
        projectsCompleted: z.array(z.string()).optional(),
        majorTurningPoints: z.array(z.string()).optional(),
        unexpectedEvents: z.array(z.string()).optional(),
        narrative: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(schema.futures).values(input);
      return { id: Number(result[0].insertId) };
    }),

  saveScores: authedQuery
    .input(
      z.object({
        simulationRunId: z.number(),
        growthPotential: z.number(),
        consistency: z.number(),
        risk: z.number(),
        opportunity: z.number(),
        discipline: z.number(),
        learning: z.number(),
        relationshipStability: z.number(),
        healthProjection: z.number(),
        careerProjection: z.number(),
        financialProjection: z.number(),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const result = await db.insert(schema.analysisScores).values(input);
      return { id: Number(result[0].insertId) };
    }),

  getScores: authedQuery
    .input(z.object({ runId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      const runRows = await db
        .select()
        .from(schema.simulationRuns)
        .where(eq(schema.simulationRuns.id, input.runId))
        .limit(1);
      const run = runRows.at(0);
      if (!run || run.userId !== ctx.user.id) return null;

      const rows = await db
        .select()
        .from(schema.analysisScores)
        .where(eq(schema.analysisScores.simulationRunId, input.runId))
        .limit(1);
      return rows.at(0) ?? null;
    }),
});
